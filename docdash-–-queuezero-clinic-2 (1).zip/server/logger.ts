import pino from 'pino';
import type Database from 'better-sqlite3';

export const logger = pino({
  name: 'docdash-queuezero',
  level: process.env.LOG_LEVEL ?? (process.env.NODE_ENV === 'test' ? 'silent' : 'info'),
  timestamp: pino.stdTimeFunctions.isoTime,
  base: { service: 'docdash-queuezero-api' },
});

export interface AuditEventInput {
  event: string;
  actorRole: string;
  actorName: string;
  doctorId?: number | null;
  tokenNumber?: number | null;
  details: Record<string, unknown>;
}

export function createAuditLogger(db: Database.Database) {
  const insertStmt = db.prepare(`
    INSERT INTO audit_logs (event, actor_role, actor_name, doctor_id, token_number, details, created_at)
    VALUES (@event, @actorRole, @actorName, @doctorId, @tokenNumber, @details, @createdAt)
  `);

  return {
    record(input: AuditEventInput): void {
      const createdAt = new Date().toISOString();
      logger.info(
        {
          auditEvent: input.event,
          actorRole: input.actorRole,
          actorName: input.actorName,
          doctorId: input.doctorId ?? null,
          tokenNumber: input.tokenNumber ?? null,
          ...input.details,
        },
        `AUDIT: ${input.event}`
      );
      try {
        insertStmt.run({
          event: input.event,
          actorRole: input.actorRole,
          actorName: input.actorName,
          doctorId: input.doctorId ?? null,
          tokenNumber: input.tokenNumber ?? null,
          details: JSON.stringify(input.details),
          createdAt,
        });
      } catch (err) {
        logger.error({ err }, 'Failed to persist audit log entry');
      }
    },
  };
}

export type AuditLogger = ReturnType<typeof createAuditLogger>;
