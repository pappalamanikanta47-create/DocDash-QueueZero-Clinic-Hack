import { Router } from 'express';
import type { ShiftType } from '../../src/types/clinic.ts';
import type { AuditLogger } from '../logger.ts';
import type { QueueService } from '../services/queueService.ts';
import { requireAuth, requireRole } from '../middleware/auth.ts';

export function createQueueRoutes(
  queueService: QueueService,
  audit: AuditLogger
): Router {
  const router = Router();

  router.get('/board', (req, res, next) => {
    try {
      const clinicId = req.query.clinicId ? Number(req.query.clinicId) : undefined;
      const doctorId = req.query.doctorId ? Number(req.query.doctorId) : undefined;
      const specialty =
        typeof req.query.specialty === 'string' ? req.query.specialty : undefined;
      const shift: ShiftType = req.query.shift === 'evening' ? 'evening' : 'morning';

      if (doctorId && Number.isInteger(doctorId) && doctorId > 0) {
        const board = queueService.getDoctorQueueBoard(doctorId, shift);
        res.json({ success: true, boards: [board] });
        return;
      }

      const boards = queueService.getAllQueueBoards({
        clinicId: clinicId && Number.isFinite(clinicId) ? clinicId : undefined,
        specialty,
        shift,
      });
      res.json({ success: true, boards });
    } catch (err) {
      next(err);
    }
  });

  router.get('/history', (req, res, next) => {
    try {
      const page = req.query.page ? Number(req.query.page) : 1;
      const limit = req.query.limit ? Number(req.query.limit) : 10;
      const clinicId = req.query.clinicId ? Number(req.query.clinicId) : undefined;
      const doctorId = req.query.doctorId ? Number(req.query.doctorId) : undefined;
      const status = typeof req.query.status === 'string' ? req.query.status : undefined;

      const history = queueService.getPaginatedTokenHistory({
        page: Number.isFinite(page) ? page : 1,
        limit: Number.isFinite(limit) ? limit : 10,
        clinicId: clinicId && Number.isFinite(clinicId) ? clinicId : undefined,
        doctorId: doctorId && Number.isFinite(doctorId) ? doctorId : undefined,
        status,
      });

      res.json({ success: true, history });
    } catch (err) {
      next(err);
    }
  });

  router.get(
    '/audit',
    requireAuth(audit),
    requireRole(audit, 'doctor', 'triage_staff'),
    (req, res, next) => {
      try {
        const limit = req.query.limit ? Number(req.query.limit) : 40;
        const logs = queueService.getAuditLogs(Number.isFinite(limit) ? limit : 40);
        res.json({ success: true, logs });
      } catch (err) {
        next(err);
      }
    }
  );

  return router;
}
