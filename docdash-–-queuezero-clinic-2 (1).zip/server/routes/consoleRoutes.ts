import fs from 'node:fs';
import path from 'node:path';
import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import type { AuditLogger } from '../logger.ts';
import type { QueueService } from '../services/queueService.ts';
import {
  requireAuth,
  requireRole,
  type AuthenticatedRequest,
} from '../middleware/auth.ts';
import { ValidationError } from '../errors.ts';

const doctorActionSchema = z.object({
  doctorId: z.coerce.number().int().positive(),
  shift: z.enum(['morning', 'evening']),
});

const completeSchema = doctorActionSchema.extend({
  durationMinutes: z.coerce.number().min(5).max(30),
});

const delaySchema = doctorActionSchema.extend({
  delayMinutes: z.coerce.number().int().min(1).max(120).default(10),
});

const statusSchema = doctorActionSchema.extend({
  status: z.enum(['In Consultation', 'On Break', 'Delayed']),
  resetDelay: z.boolean().optional().default(false),
});

const skipSchema = doctorActionSchema.extend({
  targetTokenId: z.coerce.number().int().positive().optional(),
});

const recallSchema = z.object({
  tokenId: z.coerce.number().int().positive(),
});

const emergencySchema = z.object({
  clinicId: z.coerce.number().int().positive(),
  doctorId: z.coerce.number().int().positive(),
  shift: z.enum(['morning', 'evening']),
  patientName: z.string().trim().min(2).max(120),
  patientPhone: z.string().trim().min(7).max(30),
  symptoms: z.string().trim().min(2).max(500),
});

export function createConsoleRoutes(
  queueService: QueueService,
  audit: AuditLogger,
  uploadDir: string
): Router {
  const router = Router();

  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }

  const storage = multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadDir),
    filename: (_req, file, cb) => {
      const safeName = file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_');
      cb(null, `${Date.now()}-${safeName}`);
    },
  });

  const upload = multer({
    storage,
    limits: { fileSize: 5 * 1024 * 1024 },
    fileFilter: (_req, file, cb) => {
      const allowedMimes = ['application/pdf', 'text/plain'];
      const ext = path.extname(file.originalname).toLowerCase();
      if (allowedMimes.includes(file.mimetype) || ext === '.pdf' || ext === '.txt') {
        cb(null, true);
      } else {
        cb(new ValidationError('Only PDF or plain text consultation summary files are permitted'));
      }
    },
  });

  router.post(
    '/console/call-next',
    requireAuth(audit),
    requireRole(audit, 'doctor'),
    (req: AuthenticatedRequest, res, next) => {
      try {
        const { doctorId, shift } = doctorActionSchema.parse(req.body);
        const result = queueService.callNextPatient(doctorId, shift, req.user!);
        res.json({ success: true, ...result });
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/console/complete',
    requireAuth(audit),
    requireRole(audit, 'doctor'),
    (req: AuthenticatedRequest, res, next) => {
      try {
        const { doctorId, shift, durationMinutes } = completeSchema.parse(req.body);
        const board = queueService.markConsultationCompleted(
          doctorId,
          shift,
          durationMinutes,
          req.user!
        );
        res.json({ success: true, board });
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/console/delay',
    requireAuth(audit),
    requireRole(audit, 'doctor'),
    (req: AuthenticatedRequest, res, next) => {
      try {
        const { doctorId, shift, delayMinutes } = delaySchema.parse(req.body);
        const board = queueService.delayDoctor(doctorId, shift, delayMinutes, req.user!);
        res.json({ success: true, board });
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/console/status',
    requireAuth(audit),
    requireRole(audit, 'doctor'),
    (req: AuthenticatedRequest, res, next) => {
      try {
        const { doctorId, shift, status, resetDelay } = statusSchema.parse(req.body);
        const board = queueService.updateDoctorStatus(
          doctorId,
          shift,
          status,
          req.user!,
          resetDelay
        );
        res.json({ success: true, board });
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/console/skip-absent',
    requireAuth(audit),
    requireRole(audit, 'doctor'),
    (req: AuthenticatedRequest, res, next) => {
      try {
        const { doctorId, shift, targetTokenId } = skipSchema.parse(req.body);
        const board = queueService.skipAbsentToken(
          doctorId,
          shift,
          req.user!,
          targetTokenId
        );
        res.json({ success: true, board });
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/console/recall-holding',
    requireAuth(audit),
    requireRole(audit, 'doctor'),
    (req: AuthenticatedRequest, res, next) => {
      try {
        const { tokenId } = recallSchema.parse(req.body);
        const board = queueService.recallHoldingToken(tokenId, req.user!);
        res.json({ success: true, board });
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/console/appointments/:id/prescription',
    requireAuth(audit),
    requireRole(audit, 'doctor'),
    upload.single('file'),
    (req: AuthenticatedRequest, res, next) => {
      try {
        const appointmentId = Number(req.params.id);
        if (!Number.isInteger(appointmentId) || appointmentId <= 0) {
          throw new ValidationError('Invalid appointment identifier');
        }

        const notes = typeof req.body.notes === 'string' ? req.body.notes.trim() : '';
        let fileMeta: { fileName: string; storedPath: string; mimeType: string; fileSize: number };

        if (req.file) {
          fileMeta = {
            fileName: req.file.originalname,
            storedPath: req.file.path,
            mimeType: req.file.mimetype,
            fileSize: req.file.size,
          };
        } else if (notes.length >= 3) {
          const generatedName = `consultation-summary-${appointmentId}.txt`;
          const generatedPath = path.join(uploadDir, `${Date.now()}-${generatedName}`);
          fs.writeFileSync(generatedPath, `DocDash – QueueZero Clinical Summary\nAppointment #${appointmentId}\n\n${notes}\n`);
          fileMeta = {
            fileName: generatedName,
            storedPath: generatedPath,
            mimeType: 'text/plain',
            fileSize: Buffer.byteLength(notes, 'utf-8'),
          };
        } else {
          throw new ValidationError('Provide a PDF file or consultation notes to attach');
        }

        const prescription = queueService.attachPrescription(
          appointmentId,
          fileMeta,
          notes,
          req.user!
        );
        res.status(201).json({ success: true, prescription });
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/triage/emergency',
    requireAuth(audit),
    requireRole(audit, 'triage_staff'),
    (req: AuthenticatedRequest, res, next) => {
      try {
        const payload = emergencySchema.parse(req.body);
        const result = queueService.escalateEmergencyPatient(payload, req.user!);
        res.status(201).json({ success: true, ...result });
      } catch (err) {
        next(err);
      }
    }
  );

  return router;
}
