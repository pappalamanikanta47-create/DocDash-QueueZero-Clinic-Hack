import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import type Database from 'better-sqlite3';
import type { AuthUser } from '../../src/types/clinic.ts';
import type { AuditLogger } from '../logger.ts';
import {
  AUTH_COOKIE_NAME,
  CSRF_COOKIE_NAME,
  generateCsrfToken,
  isSecureRequest,
  signAuthToken,
  type AuthenticatedRequest,
} from '../middleware/auth.ts';
import { UnauthorizedError } from '../errors.ts';

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export function createAuthRoutes(db: Database.Database, audit: AuditLogger): Router {
  const router = Router();

  router.get('/csrf', (req, res) => {
    const existing = req.cookies?.[CSRF_COOKIE_NAME] as string | undefined;
    const token = existing || generateCsrfToken();
    const secure = isSecureRequest(req);

    res.cookie(CSRF_COOKIE_NAME, token, {
      httpOnly: false,
      secure,
      sameSite: secure ? 'none' : 'lax',
      path: '/',
      maxAge: 12 * 60 * 60 * 1000,
    });

    res.json({ success: true, csrfToken: token });
  });

  router.post('/login', (req, res, next) => {
    try {
      const { email, password } = loginSchema.parse(req.body);

      const userRow = db
        .prepare('SELECT id, email, password_hash, name, role, doctor_id FROM users WHERE LOWER(email) = LOWER(?)')
        .get(email.trim()) as
        | {
            id: number;
            email: string;
            password_hash: string;
            name: string;
            role: AuthUser['role'];
            doctor_id: number | null;
          }
        | undefined;

      if (!userRow || !bcrypt.compareSync(password, userRow.password_hash)) {
        audit.record({
          event: 'AUTH_LOGIN_FAILED',
          actorRole: 'anonymous',
          actorName: email.trim(),
          details: { reason: 'invalid_credentials' },
        });
        throw new UnauthorizedError('Invalid email or password');
      }

      const user: AuthUser = {
        id: userRow.id,
        email: userRow.email,
        name: userRow.name,
        role: userRow.role,
        doctorId: userRow.doctor_id,
      };

      const jwtToken = signAuthToken(user);
      const csrfToken = generateCsrfToken();
      const secure = isSecureRequest(req);

      res.cookie(AUTH_COOKIE_NAME, jwtToken, {
        httpOnly: true,
        secure,
        sameSite: secure ? 'none' : 'lax',
        path: '/',
        maxAge: 12 * 60 * 60 * 1000,
      });

      res.cookie(CSRF_COOKIE_NAME, csrfToken, {
        httpOnly: false,
        secure,
        sameSite: secure ? 'none' : 'lax',
        path: '/',
        maxAge: 12 * 60 * 60 * 1000,
      });

      audit.record({
        event: 'AUTH_LOGIN_SUCCESS',
        actorRole: user.role,
        actorName: user.name,
        doctorId: user.doctorId,
        details: { email: user.email },
      });

      res.json({ success: true, user, csrfToken });
    } catch (err) {
      next(err);
    }
  });

  router.post('/logout', (req: AuthenticatedRequest, res) => {
    const secure = isSecureRequest(req);
    res.clearCookie(AUTH_COOKIE_NAME, {
      httpOnly: true,
      secure,
      sameSite: secure ? 'none' : 'lax',
      path: '/',
    });
    res.json({ success: true });
  });

  router.get('/me', (req: AuthenticatedRequest, res) => {
    res.json({ success: true, user: req.user ?? null });
  });

  return router;
}
