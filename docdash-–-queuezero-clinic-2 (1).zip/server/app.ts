import http from 'node:http';
import path from 'node:path';
import express from 'express';
import cookieParser from 'cookie-parser';
import { WebSocketServer, WebSocket } from 'ws';
import type Database from 'better-sqlite3';
import type { ShiftType } from '../src/types/clinic.ts';
import { initializeDatabase } from './db/database.ts';
import { createAuditLogger } from './logger.ts';
import {
  attachOptionalUser,
  createBookingRateLimiter,
  csrfProtection,
} from './middleware/auth.ts';
import { QueueService } from './services/queueService.ts';
import { createAuthRoutes } from './routes/authRoutes.ts';
import { createDirectoryRoutes } from './routes/directoryRoutes.ts';
import { createAppointmentRoutes } from './routes/appointmentRoutes.ts';
import { createQueueRoutes } from './routes/queueRoutes.ts';
import { createConsoleRoutes } from './routes/consoleRoutes.ts';
import { errorHandler } from './errors.ts';

export interface CreateAppOptions {
  dbPath?: string;
  uploadDir?: string;
  bookingRateLimitMax?: number;
}

export interface AppInstance {
  app: express.Express;
  server: http.Server;
  wss: WebSocketServer;
  db: Database.Database;
  queueService: QueueService;
  close: () => Promise<void>;
}

export function createApp(options: CreateAppOptions = {}): AppInstance {
  const dbPath =
    options.dbPath ?? path.resolve(process.cwd(), 'data', 'docdash.sqlite');
  const uploadDir =
    options.uploadDir ?? path.resolve(process.cwd(), 'data', 'uploads');

  const db = initializeDatabase(dbPath);
  const audit = createAuditLogger(db);

  const app = express();
  app.set('trust proxy', 1);
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws/queue' });

  const broadcastQueueChange = (doctorId: number, shift: ShiftType) => {
    const payload = JSON.stringify({
      type: 'queue:updated',
      doctorId,
      shift,
      timestamp: new Date().toISOString(),
    });
    for (const client of wss.clients) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(payload);
      }
    }
  };

  wss.on('connection', (socket) => {
    socket.send(
      JSON.stringify({
        type: 'queue:connected',
        timestamp: new Date().toISOString(),
      })
    );
  });

  const queueService = new QueueService(db, audit, broadcastQueueChange);

  app.use(express.json({ limit: '1mb' }));
  app.use(cookieParser());
  app.use(attachOptionalUser);
  app.use(csrfProtection(audit));

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', service: 'docdash-queuezero' });
  });

  const bookingLimiter = createBookingRateLimiter(options.bookingRateLimitMax ?? 30, 60_000);

  app.use('/api/auth', createAuthRoutes(db, audit));
  app.use('/api', createDirectoryRoutes(queueService));
  app.use('/api/appointments', createAppointmentRoutes(queueService, bookingLimiter));
  app.use('/api/queue', createQueueRoutes(queueService, audit));
  app.use('/api', createConsoleRoutes(queueService, audit, uploadDir));

  app.use(errorHandler);

  const close = async () => {
    for (const client of wss.clients) {
      client.terminate();
    }
    await new Promise<void>((resolve) => wss.close(() => resolve()));
    if (server.listening) {
      await new Promise<void>((resolve) => server.close(() => resolve()));
    }
    db.close();
  };

  return { app, server, wss, db, queueService, close };
}
