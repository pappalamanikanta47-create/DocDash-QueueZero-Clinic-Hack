import { useCallback, useEffect, useState } from 'react';
import { BrowserRouter, Route, Routes, useNavigate } from 'react-router-dom';
import type {
  Clinic,
  Doctor,
  PatientAppointmentDetail,
  ShiftType,
  Specialty,
} from './types/clinic.ts';
import {
  fetchClinics,
  fetchDoctors,
  fetchSpecialties,
} from './services/apiClient.ts';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { BookingModal } from './components/BookingModal.tsx';
import { DirectoryPage } from './pages/DirectoryPage.tsx';
import { LiveBoardPage } from './pages/LiveBoardPage.tsx';
import { MyAppointmentsPage } from './pages/MyAppointmentsPage.tsx';
import { DoctorConsolePage } from './pages/DoctorConsolePage.tsx';
import { AnalyticsPage } from './pages/AnalyticsPage.tsx';

function AppShell() {
  const navigate = useNavigate();
  const { rememberBookedAppointment } = useAuth();

  const [clinics, setClinics] = useState<Clinic[]>([]);
  const [specialties, setSpecialties] = useState<Specialty[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loadingDirectory, setLoadingDirectory] = useState(true);

  const [selectedClinicId, setSelectedClinicId] = useState<number | null>(null);
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>('All');
  const [selectedShift, setSelectedShift] = useState<ShiftType>('morning');

  const [bookingOpen, setBookingOpen] = useState(false);
  const [bookingDoctor, setBookingDoctor] = useState<Doctor | null>(null);

  const loadDirectory = useCallback(async () => {
    try {
      const [c, s, d] = await Promise.all([
        fetchClinics(),
        fetchSpecialties(),
        fetchDoctors(),
      ]);
      setClinics(c);
      setSpecialties(s);
      setDoctors(d);
    } finally {
      setLoadingDirectory(false);
    }
  }, []);

  useEffect(() => {
    void loadDirectory();
  }, [loadDirectory]);

  const handleOpenBookingForDoctor = (doctor: Doctor) => {
    setBookingDoctor(doctor);
    setBookingOpen(true);
  };

  const handleOpenQuickBook = () => {
    setBookingDoctor(doctors[0] ?? null);
    setBookingOpen(true);
  };

  const handleAppointmentBooked = (appointment: PatientAppointmentDetail) => {
    rememberBookedAppointment(appointment.appointmentId);
    setBookingOpen(false);
    void loadDirectory();
    navigate('/appointments');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <Navbar onOpenQuickBook={handleOpenQuickBook} />

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <Routes>
          <Route
            path="/"
            element={
              <DirectoryPage
                clinics={clinics}
                specialties={specialties}
                doctors={doctors}
                loading={loadingDirectory}
                selectedClinicId={selectedClinicId}
                selectedSpecialty={selectedSpecialty}
                selectedShift={selectedShift}
                onSelectClinicId={setSelectedClinicId}
                onSelectSpecialty={setSelectedSpecialty}
                onSelectShift={setSelectedShift}
                onBookDoctor={handleOpenBookingForDoctor}
              />
            }
          />
          <Route path="/board" element={<LiveBoardPage clinics={clinics} />} />
          <Route path="/appointments" element={<MyAppointmentsPage />} />
          <Route
            path="/console"
            element={<DoctorConsolePage clinics={clinics} doctors={doctors} />}
          />
          <Route path="/analytics" element={<AnalyticsPage clinics={clinics} />} />
        </Routes>
      </main>

      <BookingModal
        isOpen={bookingOpen}
        clinics={clinics}
        doctors={doctors}
        initialDoctor={bookingDoctor}
        initialShift={selectedShift}
        onClose={() => setBookingOpen(false)}
        onBooked={handleAppointmentBooked}
      />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppShell />
      </AuthProvider>
    </BrowserRouter>
  );
}
