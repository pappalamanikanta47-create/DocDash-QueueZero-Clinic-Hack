import { useEffect, useState, type FormEvent } from 'react';
import { X } from 'lucide-react';
import type {
  Clinic,
  Doctor,
  DoctorQueueBoard,
  PatientAppointmentDetail,
  ShiftType,
} from '../types/clinic.ts';
import {
  ApiError,
  bookAppointment,
  fetchQueueBoards,
} from '../services/apiClient.ts';
import { calculateRollingWait } from '../utils/queueEstimator.ts';

interface BookingModalProps {
  isOpen: boolean;
  clinics: Clinic[];
  doctors: Doctor[];
  initialDoctor: Doctor | null;
  initialShift: ShiftType;
  onClose: () => void;
  onBooked: (appointment: PatientAppointmentDetail) => void;
}

export function BookingModal({
  isOpen,
  clinics,
  doctors,
  initialDoctor,
  initialShift,
  onClose,
  onBooked,
}: BookingModalProps) {
  const [clinicId, setClinicId] = useState<number>(1);
  const [doctorId, setDoctorId] = useState<number>(1);
  const [shift, setShift] = useState<ShiftType>(initialShift);
  const [patientName, setPatientName] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [previewBoard, setPreviewBoard] = useState<DoctorQueueBoard | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setErrorMsg(null);
    const targetDoc = initialDoctor ?? doctors[0] ?? null;
    if (targetDoc) {
      setClinicId(targetDoc.clinicId);
      setDoctorId(targetDoc.id);
    } else if (clinics[0]) {
      setClinicId(clinics[0].id);
    }
    setShift(initialShift);
  }, [isOpen, initialDoctor, initialShift, doctors, clinics]);

  const clinicDoctors = doctors.filter((d) => d.clinicId === clinicId);

  useEffect(() => {
    if (!isOpen || !doctorId) return;
    let active = true;
    fetchQueueBoards({ doctorId, shift })
      .then((boards) => {
        if (active) setPreviewBoard(boards[0] ?? null);
      })
      .catch(() => {
        if (active) setPreviewBoard(null);
      });
    return () => {
      active = false;
    };
  }, [isOpen, doctorId, shift]);

  if (!isOpen) {
    return null;
  }

  const handleClinicChange = (newClinicId: number) => {
    setClinicId(newClinicId);
    const firstDoc = doctors.find((d) => d.clinicId === newClinicId);
    if (firstDoc) {
      setDoctorId(firstDoc.id);
    }
  };

  const projectedPosition = previewBoard
    ? (previewBoard.activeToken ? 1 : 0) + previewBoard.waitingTokens.length + 1
    : 1;
  const projectedWait = previewBoard
    ? calculateRollingWait(
        projectedPosition,
        previewBoard.ewmaMinutes,
        previewBoard.offsetDelayMinutes
      )
    : 0;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSubmitting(true);

    try {
      const booked = await bookAppointment({
        clinicId,
        doctorId,
        shift,
        patientName,
        patientPhone,
        symptoms,
      });
      setPatientName('');
      setPatientPhone('');
      setSymptoms('');
      onBooked(booked);
    } catch (err) {
      if (err instanceof ApiError) {
        setErrorMsg(err.message);
      } else {
        setErrorMsg('Unable to complete appointment booking. Please verify your inputs.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="booking-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 p-4 backdrop-blur-[2px]"
    >
      <div className="w-full max-w-lg rounded-xl border border-slate-200 bg-white p-6">
        <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h2 id="booking-modal-title" className="font-display text-lg font-bold text-slate-900">
              Book Consultation Token
            </h2>
            <p className="mt-0.5 text-sm text-slate-600">
              Reserve the next sequential virtual token in the live queue.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close booking dialog"
            className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label
                htmlFor="booking-clinic"
                className="block text-xs font-semibold text-slate-700"
              >
                Clinic Branch
              </label>
              <select
                id="booking-clinic"
                value={clinicId}
                onChange={(e) => handleClinicChange(Number(e.target.value))}
                className="mt-1.5 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
              >
                {clinics.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="booking-doctor"
                className="block text-xs font-semibold text-slate-700"
              >
                Doctor
              </label>
              <select
                id="booking-doctor"
                value={doctorId}
                onChange={(e) => setDoctorId(Number(e.target.value))}
                className="mt-1.5 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
              >
                {clinicDoctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} ({d.specialtyName})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <span className="block text-xs font-semibold text-slate-700">
              Consultation Shift
            </span>
            <div className="mt-1.5 grid grid-cols-2 gap-2">
              {(['morning', 'evening'] as ShiftType[]).map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => setShift(option)}
                  className={`rounded-lg border px-3 py-2 text-sm font-medium transition-colors ${
                    shift === option
                      ? 'border-teal-700 bg-teal-50 text-teal-900'
                      : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {option === 'morning' ? 'Morning (9 AM – 1 PM)' : 'Evening (4 PM – 8 PM)'}
                </button>
              ))}
            </div>
          </div>

          {previewBoard && (
            <div className="grid grid-cols-3 gap-3 rounded-lg border border-slate-200 bg-slate-50 p-3.5 text-center">
              <div>
                <div className="text-xs text-slate-500">Next Token</div>
                <div className="mt-0.5 font-mono text-base font-bold tabular-nums text-teal-800">
                  #{previewBoard.nextAvailableTokenNumber}
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-500">Now Serving</div>
                <div className="mt-0.5 font-mono text-base font-bold tabular-nums text-slate-900">
                  {previewBoard.activeToken ? `#${previewBoard.activeToken.tokenNumber}` : 'Ready'}
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-500">Est. Wait</div>
                <div className="mt-0.5 font-mono text-base font-bold tabular-nums text-slate-900">
                  {projectedWait} min
                </div>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label
                htmlFor="booking-patient-name"
                className="block text-xs font-semibold text-slate-700"
              >
                Patient Full Name
              </label>
              <input
                id="booking-patient-name"
                type="text"
                required
                minLength={2}
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                placeholder="e.g. Patient A"
                className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
              />
            </div>

            <div>
              <label
                htmlFor="booking-patient-phone"
                className="block text-xs font-semibold text-slate-700"
              >
                Mobile Phone (for SMS alerts)
              </label>
              <input
                id="booking-patient-phone"
                type="tel"
                required
                minLength={7}
                value={patientPhone}
                onChange={(e) => setPatientPhone(e.target.value)}
                placeholder="e.g. 555-0199"
                className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="booking-symptoms"
              className="block text-xs font-semibold text-slate-700"
            >
              Reason for Visit (optional)
            </label>
            <input
              id="booking-symptoms"
              type="text"
              value={symptoms}
              onChange={(e) => setSymptoms(e.target.value)}
              placeholder="Brief consultation note"
              className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
            />
          </div>

          {errorMsg && (
            <div
              role="alert"
              className="rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-sm text-red-800"
            >
              {errorMsg}
            </div>
          )}

          <div className="flex items-center justify-end gap-3 border-t border-slate-100 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="rounded-lg bg-teal-700 px-5 py-2 text-sm font-semibold text-white hover:bg-teal-800 disabled:opacity-60"
            >
              {submitting ? 'Confirming...' : 'Confirm & Issue Token'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
