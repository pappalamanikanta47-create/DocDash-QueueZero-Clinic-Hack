import { CalendarPlus } from 'lucide-react';
import type { Doctor, ShiftType } from '../types/clinic.ts';

interface DoctorCardProps {
  doctor: Doctor;
  selectedShift: ShiftType;
  onBook: (doctor: Doctor) => void;
}

export function DoctorCard({ doctor, selectedShift, onBook }: DoctorCardProps) {
  const status = selectedShift === 'morning' ? doctor.morningStatus : doctor.eveningStatus;
  const delayMinutes =
    selectedShift === 'morning' ? doctor.morningDelayMinutes : doctor.eveningDelayMinutes;

  const statusTextColor =
    status === 'Delayed'
      ? 'text-amber-700'
      : status === 'On Break'
      ? 'text-slate-500'
      : 'text-emerald-700';

  return (
    <article className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-6 transition-colors hover:border-slate-300">
      <div>
        <div className="flex items-start justify-between gap-4">
          <div>
            <h3 className="font-display text-lg font-semibold text-slate-900">
              {doctor.name}
            </h3>
            <p className="mt-0.5 text-sm text-slate-600">{doctor.credentials}</p>
          </div>
          <span className={`text-xs font-semibold whitespace-nowrap ${statusTextColor}`}>
            {status}
            {status === 'Delayed' && delayMinutes > 0 ? ` (+${delayMinutes}m)` : ''}
          </span>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-500">
          <span className="font-medium text-slate-700">{doctor.specialtyName}</span>
          <span aria-hidden="true">·</span>
          <span>{doctor.clinicName}</span>
          <span aria-hidden="true">·</span>
          <span>{doctor.roomNumber}</span>
        </div>

        <dl className="mt-5 grid grid-cols-2 gap-4 border-t border-slate-100 pt-4">
          <div>
            <dt className="text-xs text-slate-500">Avg. Consultation</dt>
            <dd className="mt-0.5 font-mono text-base font-semibold tabular-nums text-slate-900">
              {doctor.ewmaMinutes.toFixed(1)} min
            </dd>
          </div>
          <div>
            <dt className="text-xs text-slate-500">Consultation Fee</dt>
            <dd className="mt-0.5 font-mono text-base font-semibold tabular-nums text-slate-900">
              ${doctor.consultationFee}
            </dd>
          </div>
        </dl>
      </div>

      <div className="mt-6 flex items-center justify-between gap-3 pt-2">
        <span className="text-xs text-slate-500 capitalize">
          {selectedShift} outpatient shift
        </span>
        <button
          type="button"
          onClick={() => onBook(doctor)}
          aria-label={`Book token with ${doctor.name}`}
          className="inline-flex items-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-teal-800 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700"
        >
          <CalendarPlus className="h-4 w-4" />
          Book Token
        </button>
      </div>
    </article>
  );
}
