import type { HeatmapCell } from '../types/clinic.ts';

interface WaitTimeHeatmapProps {
  cells: HeatmapCell[];
  clinicName?: string;
}

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const HOURS = [
  { num: 9, label: '9 AM' },
  { num: 10, label: '10 AM' },
  { num: 11, label: '11 AM' },
  { num: 12, label: '12 PM' },
  { num: 16, label: '4 PM' },
  { num: 17, label: '5 PM' },
  { num: 18, label: '6 PM' },
];

function getHeatCellClasses(avgWait: number): string {
  if (avgWait <= 0) return 'bg-slate-100 text-slate-500';
  if (avgWait <= 14) return 'bg-emerald-100 text-emerald-950 border-emerald-200';
  if (avgWait <= 24) return 'bg-teal-100 text-teal-950 border-teal-200';
  if (avgWait <= 32) return 'bg-amber-100 text-amber-950 border-amber-200';
  return 'bg-red-100 text-red-950 border-red-200';
}

export function WaitTimeHeatmap({ cells, clinicName }: WaitTimeHeatmapProps) {
  const cellMap = new Map<string, HeatmapCell>();
  for (const c of cells) {
    cellMap.set(`${c.dayIndex}-${c.hourNum}`, c);
  }

  const populated = cells.filter((c) => c.sampleCount > 0 && c.avgWaitMinutes > 0);
  const lowestCell =
    populated.length > 0
      ? populated.reduce((best, curr) =>
          curr.avgWaitMinutes < best.avgWaitMinutes ? curr : best
        )
      : null;

  return (
    <section
      aria-label="Clinic Wait Time Heatmap"
      className="rounded-xl border border-slate-200 bg-white p-6"
    >
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            Historical Wait-Time Heatmap{clinicName ? ` — ${clinicName}` : ''}
          </h2>
          <p className="mt-1 text-sm text-slate-600">
            Average outpatient wait duration in minutes by day of week and consultation hour.
          </p>
        </div>

        {lowestCell && (
          <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-3.5 py-2 text-xs text-emerald-900">
            Lowest traffic window:{' '}
            <span className="font-semibold">
              {lowestCell.dayOfWeek} at {lowestCell.hourSlot}
            </span>{' '}
            (<span className="font-mono font-semibold tabular-nums">{lowestCell.avgWaitMinutes}m</span> avg)
          </div>
        )}
      </div>

      <div className="mt-5 overflow-x-auto">
        <table className="w-full min-w-[560px] border-separate border-spacing-1.5 text-center">
          <thead>
            <tr>
              <th className="py-1.5 text-left text-xs font-semibold text-slate-500">Day</th>
              {HOURS.map((h) => (
                <th key={h.num} className="py-1.5 text-xs font-semibold text-slate-600">
                  {h.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {DAYS.map((day, dayIndex) => (
              <tr key={day}>
                <td className="py-1 text-left text-xs font-semibold text-slate-700">{day}</td>
                {HOURS.map((h) => {
                  const cell = cellMap.get(`${dayIndex}-${h.num}`);
                  const avg = cell?.avgWaitMinutes ?? 0;
                  const samples = cell?.sampleCount ?? 0;
                  return (
                    <td key={h.num}>
                      <div
                        title={`${day} ${h.label}: ${avg} min avg (${samples} consultations)`}
                        className={`rounded-md border px-2 py-2.5 font-mono text-xs font-semibold tabular-nums ${getHeatCellClasses(
                          avg
                        )}`}
                      >
                        {avg > 0 ? `${avg}m` : '—'}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-4 border-t border-slate-100 pt-3 text-xs text-slate-600">
        <span className="font-medium text-slate-700">Wait Intensity:</span>
        <span className="inline-flex items-center gap-1.5">
          <span className="h-3 w-3 rounded bg-emerald-100 border border-emerald-200" />
          Low (&le;14m)
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="h-3 w-3 rounded bg-teal-100 border border-teal-200" />
          Moderate (15–24m)
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="h-3 w-3 rounded bg-amber-100 border border-amber-200" />
          Busy (25–32m)
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="h-3 w-3 rounded bg-red-100 border border-red-200" />
          Peak (&gt;32m)
        </span>
      </div>
    </section>
  );
}
