import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateEwma,
  calculatePrimaryWait,
  calculateRollingWait,
  clampConsultationDuration,
  computeQueueWaitSnapshots,
  generateNextTokenNumber,
  sortWaitingTokens,
} from './queueEstimator.ts';
import { calculateDistanceMeters, isWithinCheckInRadius } from './geo.ts';
import type { QueueTokenItem } from '../types/clinic.ts';

function makeToken(overrides: Partial<QueueTokenItem>): QueueTokenItem {
  return {
    id: overrides.id ?? 1,
    appointmentId: overrides.appointmentId ?? 1,
    clinicId: 1,
    doctorId: 1,
    shift: 'morning',
    tokenNumber: overrides.tokenNumber ?? 1,
    status: overrides.status ?? 'waiting',
    isEmergency: overrides.isEmergency ?? false,
    priorityRank: overrides.priorityRank ?? 100,
    patientName: overrides.patientName ?? 'Patient',
    patientPhone: '555-0100',
    checkedIn: false,
    checkedInAt: null,
    calledAt: null,
    completedAt: null,
    consultationDuration: null,
    smsAlertSent: overrides.smsAlertSent ?? false,
    createdAt: '2026-11-20T08:00:00.000Z',
  };
}

test('sequential token generation increments from max existing token', () => {
  assert.equal(generateNextTokenNumber([]), 1);
  assert.equal(generateNextTokenNumber([1, 2, 3, 13]), 14);
  assert.equal(generateNextTokenNumber([5, 2, 11]), 12);
});

test('consultation duration clamps between 5 and 30 minutes', () => {
  assert.equal(clampConsultationDuration(2), 5);
  assert.equal(clampConsultationDuration(14), 14);
  assert.equal(clampConsultationDuration(45), 30);
});

test('EWMA calculates over last 5 consultations and responds to recent pacing', () => {
  assert.equal(calculateEwma([], 12), 12);
  assert.equal(calculateEwma([12, 12, 12, 12, 12], 12), 12);
  // Last 5 of 7 items: [10, 12, 14, 16, 20] with alpha = 0.4
  const ewma = calculateEwma([30, 30, 10, 12, 14, 16, 20], 12, 0.4);
  // Step-by-step: 10 -> 10.8 -> 12.08 -> 13.648 -> 16.1888 -> 16.19
  assert.equal(ewma, 16.19);
});

test('primary and rolling wait-time formulas match Patient A demo math', () => {
  // Initial demo: Token #14, Active #11, avg 12m => 36m
  assert.equal(calculatePrimaryWait(14, 11, 12), 36);
  // Next patient called: Token #14, Active #12, avg 12m => 24m
  assert.equal(calculatePrimaryWait(14, 12, 12), 24);
  // Rolling wait with QueuePosition 4 (3 ahead) and 0 delay => 36m
  assert.equal(calculateRollingWait(4, 12, 0), 36);
  // Rolling wait with QueuePosition 3 (2 ahead) and 10m doctor delay => 34m
  assert.equal(calculateRollingWait(3, 12, 10), 34);
});

test('computeQueueWaitSnapshots reproduces Patient A demo transition and SMS trigger at 2 tokens away', () => {
  const initialTokens: QueueTokenItem[] = [
    makeToken({ id: 11, tokenNumber: 11, status: 'in_consultation', patientName: 'P11' }),
    makeToken({ id: 12, tokenNumber: 12, status: 'waiting', patientName: 'P12' }),
    makeToken({ id: 13, tokenNumber: 13, status: 'waiting', patientName: 'P13' }),
    makeToken({ id: 14, tokenNumber: 14, status: 'waiting', patientName: 'Patient A' }),
  ];

  const initial = computeQueueWaitSnapshots({
    tokens: initialTokens,
    dynamicAvgMinutes: 12,
    offsetDelayMinutes: 0,
  });

  const p14Initial = initial.snapshotsById.get(14)!;
  assert.equal(initial.activeToken?.tokenNumber, 11);
  assert.equal(p14Initial.patientsAhead, 3);
  assert.equal(p14Initial.estimatedWaitMinutes, 36);
  assert.equal(p14Initial.shouldTriggerSmsAlert, false);

  // Doctor advances to #12
  const updatedTokens: QueueTokenItem[] = [
    makeToken({ id: 11, tokenNumber: 11, status: 'completed', patientName: 'P11' }),
    makeToken({ id: 12, tokenNumber: 12, status: 'in_consultation', patientName: 'P12' }),
    makeToken({ id: 13, tokenNumber: 13, status: 'waiting', patientName: 'P13' }),
    makeToken({ id: 14, tokenNumber: 14, status: 'waiting', patientName: 'Patient A' }),
  ];

  const afterNext = computeQueueWaitSnapshots({
    tokens: updatedTokens,
    dynamicAvgMinutes: 12,
    offsetDelayMinutes: 0,
  });

  const p14After = afterNext.snapshotsById.get(14)!;
  assert.equal(afterNext.activeToken?.tokenNumber, 12);
  assert.equal(p14After.patientsAhead, 2);
  assert.equal(p14After.estimatedWaitMinutes, 24);
  assert.equal(p14After.shouldTriggerSmsAlert, true);
});

test('emergency priority and absent-skip handling recalculate queue positions accurately', () => {
  const tokens: QueueTokenItem[] = [
    makeToken({ id: 12, tokenNumber: 12, status: 'in_consultation' }),
    makeToken({ id: 13, tokenNumber: 13, status: 'holding' }), // skipped absent
    makeToken({ id: 14, tokenNumber: 14, status: 'waiting', priorityRank: 100 }),
    makeToken({ id: 15, tokenNumber: 15, status: 'waiting', isEmergency: true, priorityRank: 1 }),
  ];

  const sorted = sortWaitingTokens(tokens);
  assert.deepEqual(
    sorted.map((t) => t.tokenNumber),
    [15, 14]
  );

  const result = computeQueueWaitSnapshots({
    tokens,
    dynamicAvgMinutes: 12,
    offsetDelayMinutes: 10,
  });

  // Emergency token #15 jumps ahead of #14 (only #12 in consultation is ahead of #15)
  assert.equal(result.snapshotsById.get(15)?.patientsAhead, 1);
  assert.equal(result.snapshotsById.get(15)?.estimatedWaitMinutes, 22);
  // Token #14 has #12 and #15 ahead (#13 is skipped in holding) => 2 ahead
  assert.equal(result.snapshotsById.get(14)?.patientsAhead, 2);
  assert.equal(result.snapshotsById.get(14)?.estimatedWaitMinutes, 34);
});

test('geolocation check-in validates 500m clinic radius accurately', () => {
  const clinicLat = 37.7749;
  const clinicLon = -122.4194;

  // ~200m away
  const near = isWithinCheckInRadius(37.7765, -122.4194, clinicLat, clinicLon);
  assert.equal(near.withinRadius, true);
  assert.ok(near.distanceMeters <= 500);

  // ~2km away
  const far = isWithinCheckInRadius(37.795, -122.4194, clinicLat, clinicLon);
  assert.equal(far.withinRadius, false);
  assert.ok(calculateDistanceMeters(37.795, -122.4194, clinicLat, clinicLon) > 500);
});
