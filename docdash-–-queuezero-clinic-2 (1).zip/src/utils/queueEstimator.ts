import type { ComputedTokenSnapshot, QueueTokenItem } from '../types/clinic.ts';

export const MIN_CONSULTATION_MINUTES = 5;
export const MAX_CONSULTATION_MINUTES = 30;
export const EWMA_WINDOW_SIZE = 5;
export const DEFAULT_EWMA_ALPHA = 0.4;
export const SMS_ALERT_TOKEN_DISTANCE = 2;

export function clampConsultationDuration(minutes: number): number {
  if (!Number.isFinite(minutes)) {
    return MIN_CONSULTATION_MINUTES;
  }
  return Math.min(MAX_CONSULTATION_MINUTES, Math.max(MIN_CONSULTATION_MINUTES, Math.round(minutes)));
}

/**
 * Computes Exponentially Weighted Moving Average (EWMA) over the doctor's
 * most recent 5 consultation durations (clamped between 5 and 30 minutes).
 */
export function calculateEwma(
  recentDurations: number[],
  fallbackAverage: number,
  alpha: number = DEFAULT_EWMA_ALPHA
): number {
  const window = recentDurations.slice(-EWMA_WINDOW_SIZE);
  if (window.length === 0) {
    return Math.round(fallbackAverage * 100) / 100;
  }
  const clamped = window.map(clampConsultationDuration);
  let ewma = clamped[0];
  for (let i = 1; i < clamped.length; i += 1) {
    ewma = alpha * clamped[i] + (1 - alpha) * ewma;
  }
  return Math.round(ewma * 100) / 100;
}

/**
 * Primary linear wait-time formula:
 * (CurrentToken - ActiveToken) * DoctorAverageConsultationTime
 */
export function calculatePrimaryWait(
  currentToken: number,
  activeToken: number,
  doctorAvgMinutes: number
): number {
  const delta = Math.max(0, currentToken - activeToken);
  return Math.max(0, Math.round(delta * doctorAvgMinutes));
}

/**
 * Rolling-average estimation formula with doctor offset delay:
 * (QueuePosition - 1) * DynamicAverageDuration + DoctorOffsetDelay
 */
export function calculateRollingWait(
  queuePosition: number,
  dynamicAverageDuration: number,
  doctorOffsetDelay: number = 0
): number {
  const effectiveAhead = Math.max(0, queuePosition - 1);
  return Math.max(0, Math.round(effectiveAhead * dynamicAverageDuration + Math.max(0, doctorOffsetDelay)));
}

/**
 * Generates the next sequential token number within a doctor + clinic + shift scope.
 */
export function generateNextTokenNumber(existingTokenNumbers: number[]): number {
  if (existingTokenNumbers.length === 0) {
    return 1;
  }
  let max = 0;
  for (const num of existingTokenNumbers) {
    if (Number.isFinite(num) && num > max) {
      max = num;
    }
  }
  return max + 1;
}

/**
 * Orders waiting queue tokens respecting emergency escalation priority first,
 * then explicit priority rank, then sequential token number.
 */
export function sortWaitingTokens<
  T extends Pick<QueueTokenItem, 'status' | 'isEmergency' | 'priorityRank' | 'tokenNumber'>
>(tokens: T[]): T[] {
  return [...tokens]
    .filter((t) => t.status === 'waiting')
    .sort((a, b) => {
      if (a.isEmergency !== b.isEmergency) {
        return a.isEmergency ? -1 : 1;
      }
      if (a.priorityRank !== b.priorityRank) {
        return a.priorityRank - b.priorityRank;
      }
      return a.tokenNumber - b.tokenNumber;
    });
}

/**
 * Computes live queue positions, patients ahead, dynamic wait times,
 * and SMS alert eligibility (when 2 tokens away) for an entire doctor/shift queue.
 */
export function computeQueueWaitSnapshots(params: {
  tokens: QueueTokenItem[];
  dynamicAvgMinutes: number;
  offsetDelayMinutes: number;
}): {
  activeToken: ComputedTokenSnapshot | null;
  nextToken: ComputedTokenSnapshot | null;
  waitingTokens: ComputedTokenSnapshot[];
  snapshotsById: Map<number, ComputedTokenSnapshot>;
} {
  const { tokens, dynamicAvgMinutes, offsetDelayMinutes } = params;
  const snapshotsById = new Map<number, ComputedTokenSnapshot>();

  const rawActive = tokens.find((t) => t.status === 'in_consultation') ?? null;
  let activeToken: ComputedTokenSnapshot | null = null;

  if (rawActive) {
    activeToken = {
      ...rawActive,
      queuePosition: 1,
      patientsAhead: 0,
      estimatedWaitMinutes: 0,
      shouldTriggerSmsAlert: false,
    };
    snapshotsById.set(activeToken.id, activeToken);
  }

  const orderedWaiting = sortWaitingTokens(tokens);
  const startPosition = activeToken ? 2 : 1;

  const waitingTokens: ComputedTokenSnapshot[] = orderedWaiting.map((token, idx) => {
    const queuePosition = startPosition + idx;
    const patientsAhead = queuePosition - 1;
    const estimatedWaitMinutes = calculateRollingWait(
      queuePosition,
      dynamicAvgMinutes,
      offsetDelayMinutes
    );
    const shouldTriggerSmsAlert =
      patientsAhead === SMS_ALERT_TOKEN_DISTANCE ||
      (patientsAhead > 0 && patientsAhead <= SMS_ALERT_TOKEN_DISTANCE && token.smsAlertSent);

    const snapshot: ComputedTokenSnapshot = {
      ...token,
      queuePosition,
      patientsAhead,
      estimatedWaitMinutes,
      shouldTriggerSmsAlert,
    };
    snapshotsById.set(snapshot.id, snapshot);
    return snapshot;
  });

  for (const token of tokens) {
    if (!snapshotsById.has(token.id)) {
      snapshotsById.set(token.id, {
        ...token,
        queuePosition: null,
        patientsAhead: null,
        estimatedWaitMinutes: null,
        shouldTriggerSmsAlert: false,
      });
    }
  }

  return {
    activeToken,
    nextToken: waitingTokens[0] ?? null,
    waitingTokens,
    snapshotsById,
  };
}
