const EARTH_RADIUS_METERS = 6371000;
export const CLINIC_CHECKIN_RADIUS_METERS = 500;

function toRadians(degrees: number): number {
  return (degrees * Math.PI) / 180;
}

/**
 * Haversine distance between two WGS84 coordinates in meters.
 */
export function calculateDistanceMeters(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) *
      Math.cos(toRadians(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(EARTH_RADIUS_METERS * c);
}

export function isWithinCheckInRadius(
  patientLat: number,
  patientLon: number,
  clinicLat: number,
  clinicLon: number,
  maxRadiusMeters: number = CLINIC_CHECKIN_RADIUS_METERS
): { withinRadius: boolean; distanceMeters: number } {
  const distanceMeters = calculateDistanceMeters(patientLat, patientLon, clinicLat, clinicLon);
  return {
    withinRadius: distanceMeters <= maxRadiusMeters,
    distanceMeters,
  };
}
