import { useCallback, useEffect, useState } from 'react';
import type { Clinic, HeatmapCell, PaginatedTokenHistory } from '../types/clinic.ts';
import { fetchHeatmap, fetchTokenHistory } from '../services/apiClient.ts';
import { WaitTimeHeatmap } from '../components/WaitTimeHeatmap.tsx';
import { TokenHistoryTable } from '../components/TokenHistoryTable.tsx';

interface AnalyticsPageProps {
  clinics: Clinic[];
}

export function AnalyticsPage({ clinics }: AnalyticsPageProps) {
  const [clinicId, setClinicId] = useState<number | null>(null);
  const [heatmapCells, setHeatmapCells] = useState<HeatmapCell[]>([]);
  const [history, setHistory] = useState<PaginatedTokenHistory | null>(null);
  const [statusFilter, setStatusFilter] = useState('all');
  const [page, setPage] = useState(1);
  const [loadingHistory, setLoadingHistory] = useState(true);

  const loadAnalytics = useCallback(async () => {
    setLoadingHistory(true);
    try {
      const [cells, hist] = await Promise.all([
        fetchHeatmap(clinicId ?? undefined),
        fetchTokenHistory({
          page,
          limit: 10,
          clinicId: clinicId ?? undefined,
          status: statusFilter,
        }),
      ]);
      setHeatmapCells(cells);
      setHistory(hist);
    } finally {
      setLoadingHistory(false);
    }
  }, [clinicId, page, statusFilter]);

  useEffect(() => {
    void loadAnalytics();
  }, [loadAnalytics]);

  const selectedClinicName = clinics.find((c) => c.id === clinicId)?.name;

  return (
    <div className="space-y-6">
      <section className="rounded-xl border border-slate-200 bg-white p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="font-display text-2xl font-bold text-slate-900">
              Clinic Wait-Time Analytics &amp; Token History
            </h1>
            <p className="mt-1 text-sm text-slate-600">
              Identify low-traffic outpatient hours and browse paginated historical token logs.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <label htmlFor="analytics-clinic-select" className="text-xs font-semibold text-slate-600">
              Branch:
            </label>
            <select
              id="analytics-clinic-select"
              value={clinicId ?? ''}
              onChange={(e) => {
                setClinicId(e.target.value ? Number(e.target.value) : null);
                setPage(1);
              }}
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
            >
              <option value="">All Clinics Combined</option>
              {clinics.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </section>

      <WaitTimeHeatmap cells={heatmapCells} clinicName={selectedClinicName} />

      <TokenHistoryTable
        history={history}
        loading={loadingHistory}
        statusFilter={statusFilter}
        onStatusFilterChange={(nextStatus) => {
          setStatusFilter(nextStatus);
          setPage(1);
        }}
        onPageChange={(nextPage) => setPage(nextPage)}
      />
    </div>
  );
}
