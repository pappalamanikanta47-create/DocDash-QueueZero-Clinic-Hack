import { useEffect, useState } from 'react';
import { Building2, Clock, Stethoscope } from 'lucide-react';
import type { Clinic, Doctor, ShiftType, Specialty } from '../types/clinic.ts';
import { DoctorCard } from '../components/DoctorCard.tsx';

interface DirectoryPageProps {
  clinics: Clinic[];
  specialties: Specialty[];
  doctors: Doctor[];
  loading: boolean;
  selectedClinicId: number | null;
  selectedSpecialty: string;
  selectedShift: ShiftType;
  onSelectClinicId: (clinicId: number | null) => void;
  onSelectSpecialty: (specialty: string) => void;
  onSelectShift: (shift: ShiftType) => void;
  onBookDoctor: (doctor: Doctor) => void;
}

export function DirectoryPage({
  clinics,
  specialties,
  doctors,
  loading,
  selectedClinicId,
  selectedSpecialty,
  selectedShift,
  onSelectClinicId,
  onSelectSpecialty,
  onSelectShift,
  onBookDoctor,
}: DirectoryPageProps) {
  const [filteredDoctors, setFilteredDoctors] = useState<Doctor[]>(doctors);

  useEffect(() => {
    const next = doctors.filter((doc) => {
      if (selectedClinicId && doc.clinicId !== selectedClinicId) return false;
      if (selectedSpecialty !== 'All' && doc.specialtyName !== selectedSpecialty) {
        return false;
      }
      return true;
    });
    setFilteredDoctors(next);
  }, [doctors, selectedClinicId, selectedSpecialty]);

  const activeClinic = clinics.find((c) => c.id === selectedClinicId) ?? null;

  return (
    <div className="space-y-8">
      <section className="rounded-xl border border-slate-200 bg-white p-6 sm:p-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <p className="text-xs font-semibold tracking-wide text-teal-700">
              QueueZero Outpatient Network
            </p>
            <h1 className="mt-2 font-display text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl text-balance">
              Live Outpatient Doctor Directory &amp; Virtual Queue Booking
            </h1>
            <p className="mt-3 text-base text-slate-600 leading-relaxed">
              Browse specialists across four city clinics, check real-time consultation pacing
              calculated via five-visit EWMA, and book sequential virtual tokens from home.
            </p>
          </div>

          <dl className="grid grid-cols-3 gap-6 border-t border-slate-100 pt-4 lg:border-t-0 lg:pt-0">
            <div>
              <dt className="text-xs text-slate-500">Clinics</dt>
              <dd className="mt-0.5 font-mono text-2xl font-bold tabular-nums text-slate-900">
                {clinics.length}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500">Specialists</dt>
              <dd className="mt-0.5 font-mono text-2xl font-bold tabular-nums text-slate-900">
                {doctors.length}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500">Specialties</dt>
              <dd className="mt-0.5 font-mono text-2xl font-bold tabular-nums text-slate-900">
                {specialties.length}
              </dd>
            </div>
          </dl>
        </div>

        <div className="mt-6 flex flex-col gap-4 border-t border-slate-100 pt-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap items-center gap-1.5 rounded-lg bg-slate-100 p-1">
            {['All', ...specialties.map((s) => s.name)].map((specName) => {
              const active = selectedSpecialty === specName;
              return (
                <button
                  key={specName}
                  type="button"
                  onClick={() => onSelectSpecialty(specName)}
                  className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'bg-white text-slate-950 font-semibold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {specName}
                </button>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              <Building2 className="h-4 w-4 text-slate-500" />
              <label htmlFor="directory-clinic-select" className="sr-only">
                Filter by Clinic Branch
              </label>
              <select
                id="directory-clinic-select"
                value={selectedClinicId ?? ''}
                onChange={(e) =>
                  onSelectClinicId(e.target.value ? Number(e.target.value) : null)
                }
                className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
              >
                <option value="">All Clinic Branches</option>
                {clinics.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.neighborhood})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
              <Clock className="ml-2 mr-1 h-3.5 w-3.5 text-slate-500" />
              {(['morning', 'evening'] as ShiftType[]).map((shiftOption) => (
                <button
                  key={shiftOption}
                  type="button"
                  onClick={() => onSelectShift(shiftOption)}
                  className={`rounded-md px-2.5 py-1 text-xs font-medium capitalize transition-colors whitespace-nowrap ${
                    selectedShift === shiftOption
                      ? 'bg-white text-slate-950 font-semibold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {shiftOption}
                </button>
              ))}
            </div>
          </div>
        </div>

        {activeClinic && (
          <div className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-600">
            <span className="font-semibold text-slate-800">{activeClinic.name}</span>
            <span aria-hidden="true">·</span>
            <span>{activeClinic.address}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">{activeClinic.phone}</span>
          </div>
        )}
      </section>

      <section aria-label="Available Doctors">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-lg font-bold text-slate-900">
            Available Specialists ({filteredDoctors.length})
          </h2>
          <span className="text-xs text-slate-500">
            Showing {selectedShift} shift consultation speeds
          </span>
        </div>

        {loading && doctors.length === 0 ? (
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map((n) => (
              <div
                key={n}
                className="h-56 animate-pulse rounded-xl border border-slate-200 bg-white p-6"
              />
            ))}
          </div>
        ) : filteredDoctors.length === 0 ? (
          <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
            <Stethoscope className="mx-auto h-8 w-8 text-slate-400" />
            <h3 className="mt-3 font-display text-base font-semibold text-slate-900">
              No doctors match these filters
            </h3>
            <p className="mt-1 text-sm text-slate-600">
              Try selecting a different specialty or viewing all clinic branches.
            </p>
            <button
              type="button"
              onClick={() => {
                onSelectClinicId(null);
                onSelectSpecialty('All');
              }}
              className="mt-4 rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Reset Directory Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
            {filteredDoctors.map((doctor) => (
              <DoctorCard
                key={doctor.id}
                doctor={doctor}
                selectedShift={selectedShift}
                onBook={onBookDoctor}
              />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
