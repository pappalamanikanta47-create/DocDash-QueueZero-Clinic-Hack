import { useCallback, useEffect, useState, type FormEvent } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  FileUp,
  LogOut,
  Play,
  RotateCcw,
  ShieldCheck,
  UserX,
} from 'lucide-react';
import type {
  AuditLogEntry,
  Clinic,
  Doctor,
  DoctorQueueBoard,
  DoctorStatusType,
  PatientAppointmentDetail,
  ShiftType,
} from '../types/clinic.ts';
import {
  ApiError,
  doctorAddDelay,
  doctorCallNext,
  doctorMarkCompleted,
  doctorRecallHolding,
  doctorSetStatus,
  doctorSkipAbsent,
  fetchAppointments,
  fetchAuditLogs,
  fetchQueueBoards,
  triageEscalateEmergency,
  uploadPrescriptionAttachment,
} from '../services/apiClient.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { useQueueSync } from '../hooks/useQueueSync.ts';

interface DoctorConsolePageProps {
  clinics: Clinic[];
  doctors: Doctor[];
}

export function DoctorConsolePage({ clinics, doctors }: DoctorConsolePageProps) {
  const { user, authLoading, login, logout } = useAuth();

  // Login form state
  const [email, setEmail] = useState('dr.mehta@queuezero.clinic');
  const [password, setPassword] = useState('Doctor@123');
  const [authError, setAuthError] = useState<string | null>(null);
  const [loggingIn, setLoggingIn] = useState(false);

  // Doctor Console state
  const [shift, setShift] = useState<ShiftType>('morning');
  const [board, setBoard] = useState<DoctorQueueBoard | null>(null);
  const [completedDuration, setCompletedDuration] = useState<number>(12);
  const [actionBusy, setActionBusy] = useState(false);
  const [actionFeedback, setActionFeedback] = useState<{
    message: string;
    isError: boolean;
  } | null>(null);

  // Prescription upload state
  const [doctorAppointments, setDoctorAppointments] = useState<PatientAppointmentDetail[]>([]);
  const [rxAppointmentId, setRxAppointmentId] = useState<number>(0);
  const [rxNotes, setRxNotes] = useState('');
  const [rxFile, setRxFile] = useState<File | null>(null);

  // Triage Emergency state
  const [triageClinicId, setTriageClinicId] = useState<number>(1);
  const [triageDoctorId, setTriageDoctorId] = useState<number>(1);
  const [triageShift, setTriageShift] = useState<ShiftType>('morning');
  const [triageName, setTriageName] = useState('');
  const [triagePhone, setTriagePhone] = useState('');
  const [triageSymptoms, setTriageSymptoms] = useState('');

  // Audit trail
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);

  const activeDoctorId =
    user?.role === 'doctor' ? user.doctorId ?? 1 : triageDoctorId;

  const loadConsoleData = useCallback(async () => {
    if (!user || user.role === 'patient') return;
    try {
      const targetDocId = user.role === 'doctor' ? user.doctorId ?? 1 : triageDoctorId;
      const targetShift = user.role === 'doctor' ? shift : triageShift;
      const [boards, logs] = await Promise.all([
        fetchQueueBoards({ doctorId: targetDocId, shift: targetShift }),
        fetchAuditLogs(20),
      ]);
      const currentBoard = boards[0] ?? null;
      setBoard(currentBoard);
      setAuditLogs(logs);

      if (user.role === 'doctor') {
        const allAppts = await fetchAppointments();
        const mine = allAppts.filter((a) => a.doctor.id === targetDocId);
        setDoctorAppointments(mine);
        if (currentBoard?.activeToken && rxAppointmentId === 0) {
          setRxAppointmentId(currentBoard.activeToken.appointmentId);
        } else if (mine[0] && rxAppointmentId === 0) {
          setRxAppointmentId(mine[0].appointmentId);
        }
      }
    } catch {
      // Errors handled softly on poll
    }
  }, [user, shift, triageDoctorId, triageShift, rxAppointmentId]);

  useEffect(() => {
    void loadConsoleData();
  }, [loadConsoleData]);

  useQueueSync(() => {
    void loadConsoleData();
  }, 3000);

  const handleLoginSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setLoggingIn(true);
    try {
      await login(email, password);
    } catch (err) {
      setAuthError(
        err instanceof ApiError ? err.message : 'Invalid clinical credentials'
      );
    } finally {
      setLoggingIn(false);
    }
  };

  const quickLogin = async (presetEmail: string, presetPassword: string) => {
    setEmail(presetEmail);
    setPassword(presetPassword);
    setAuthError(null);
    setLoggingIn(true);
    try {
      await login(presetEmail, presetPassword);
    } catch (err) {
      setAuthError(
        err instanceof ApiError ? err.message : 'Unable to authenticate'
      );
    } finally {
      setLoggingIn(false);
    }
  };

  const runDoctorAction = async (
    fn: () => Promise<DoctorQueueBoard>,
    successMsg: string
  ) => {
    setActionBusy(true);
    setActionFeedback(null);
    try {
      const updated = await fn();
      setBoard(updated);
      setActionFeedback({ message: successMsg, isError: false });
      const logs = await fetchAuditLogs(20);
      setAuditLogs(logs);
    } catch (err) {
      setActionFeedback({
        message: err instanceof ApiError ? err.message : 'Action failed',
        isError: true,
      });
    } finally {
      setActionBusy(false);
    }
  };

  const handlePrescriptionUpload = async (e: FormEvent) => {
    e.preventDefault();
    if (!rxAppointmentId) {
      setActionFeedback({ message: 'Select an appointment record first.', isError: true });
      return;
    }
    setActionBusy(true);
    setActionFeedback(null);
    try {
      const saved = await uploadPrescriptionAttachment(rxAppointmentId, rxNotes, rxFile);
      setActionFeedback({
        message: `Attached "${saved.fileName}" to Appointment #${saved.appointmentId}.`,
        isError: false,
      });
      setRxNotes('');
      setRxFile(null);
      await loadConsoleData();
    } catch (err) {
      setActionFeedback({
        message: err instanceof ApiError ? err.message : 'Prescription upload failed',
        isError: true,
      });
    } finally {
      setActionBusy(false);
    }
  };

  const handleTriageEmergency = async (e: FormEvent) => {
    e.preventDefault();
    setActionBusy(true);
    setActionFeedback(null);
    try {
      const res = await triageEscalateEmergency({
        clinicId: triageClinicId,
        doctorId: triageDoctorId,
        shift: triageShift,
        patientName: triageName,
        patientPhone: triagePhone,
        symptoms: triageSymptoms,
      });
      setBoard(res.board);
      setTriageName('');
      setTriagePhone('');
      setTriageSymptoms('');
      setActionFeedback({
        message: `Emergency Token #${res.appointment.tokenNumber} escalated to priority front of queue.`,
        isError: false,
      });
      const logs = await fetchAuditLogs(20);
      setAuditLogs(logs);
    } catch (err) {
      setActionFeedback({
        message: err instanceof ApiError ? err.message : 'Emergency escalation failed',
        isError: true,
      });
    } finally {
      setActionBusy(false);
    }
  };

  if (authLoading) {
    return (
      <div className="h-48 animate-pulse rounded-xl border border-slate-200 bg-white p-6" />
    );
  }

  if (!user) {
    return (
      <div className="mx-auto max-w-xl space-y-6">
        <section className="rounded-xl border border-slate-200 bg-white p-6 sm:p-8">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-teal-50 text-teal-700">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <h1 className="font-display text-xl font-bold text-slate-900">
                Protected Clinical Staff &amp; Doctor Console
              </h1>
              <p className="text-sm text-slate-600">
                Sign in with Doctor or Triage Staff credentials to manage queues.
              </p>
            </div>
          </div>

          <form onSubmit={handleLoginSubmit} className="mt-6 space-y-4">
            <div>
              <label htmlFor="login-email" className="block text-xs font-semibold text-slate-700">
                Staff Email
              </label>
              <input
                id="login-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
              />
            </div>

            <div>
              <label
                htmlFor="login-password"
                className="block text-xs font-semibold text-slate-700"
              >
                Password
              </label>
              <input
                id="login-password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
              />
            </div>

            {authError && (
              <div
                role="alert"
                className="rounded-lg border border-red-200 bg-red-50 px-3.5 py-2 text-sm text-red-800"
              >
                {authError}
              </div>
            )}

            <button
              type="submit"
              disabled={loggingIn}
              className="w-full rounded-lg bg-teal-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-teal-800 disabled:opacity-60"
            >
              {loggingIn ? 'Authenticating...' : 'Sign In to Console'}
            </button>
          </form>

          <div className="mt-6 border-t border-slate-100 pt-5">
            <h2 className="text-xs font-semibold text-slate-500">
              Quick Role Access (Seeded Evaluation Accounts)
            </h2>
            <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
              <button
                type="button"
                onClick={() => void quickLogin('dr.mehta@queuezero.clinic', 'Doctor@123')}
                className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-left text-xs hover:bg-slate-100"
              >
                <div className="font-semibold text-slate-900">Dr. Arjun Mehta</div>
                <div className="text-slate-600">Role: doctor · Cardiology</div>
              </button>
              <button
                type="button"
                onClick={() => void quickLogin('triage@queuezero.clinic', 'Triage@123')}
                className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-left text-xs hover:bg-slate-100"
              >
                <div className="font-semibold text-slate-900">Triage Desk Lead</div>
                <div className="text-slate-600">Role: triage_staff · Emergency</div>
              </button>
              <button
                type="button"
                onClick={() => void quickLogin('dr.sharma@queuezero.clinic', 'Doctor@123')}
                className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-left text-xs hover:bg-slate-100"
              >
                <div className="font-semibold text-slate-900">Dr. Priya Sharma</div>
                <div className="text-slate-600">Role: doctor · General Medicine</div>
              </button>
              <button
                type="button"
                onClick={() => void quickLogin('patient@queuezero.clinic', 'Patient@123')}
                className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-left text-xs hover:bg-slate-100"
              >
                <div className="font-semibold text-slate-900">Patient A</div>
                <div className="text-slate-600">Role: patient (RBAC Restricted)</div>
              </button>
            </div>
          </div>
        </section>
      </div>
    );
  }

  if (user.role === 'patient') {
    return (
      <section className="mx-auto max-w-xl rounded-xl border border-red-200 bg-white p-8 text-center">
        <h1 className="font-display text-xl font-bold text-slate-900">
          Unauthorized Role Access
        </h1>
        <p className="mt-2 text-sm text-slate-600">
          Signed in as <span className="font-semibold text-slate-900">{user.name}</span> (role:{' '}
          <span className="font-mono">{user.role}</span>). Doctor and Triage Console controls are
          restricted by Role-Based Access Control.
        </p>
        <button
          type="button"
          onClick={() => void logout()}
          className="mt-5 inline-flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
        >
          <LogOut className="h-4 w-4" />
          Sign Out &amp; Switch Account
        </button>
      </section>
    );
  }

  const triageClinicDoctors = doctors.filter((d) => d.clinicId === triageClinicId);

  return (
    <div className="space-y-6">
      <section className="rounded-xl border border-slate-200 bg-white p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-medium text-teal-700">
              <span>{user.role === 'doctor' ? 'Doctor Consultation Control Console' : 'Triage Emergency Escalation Desk'}</span>
              <span aria-hidden="true">·</span>
              <span>{user.email}</span>
            </div>
            <h1 className="mt-1 font-display text-2xl font-bold text-slate-900">
              {user.name}
            </h1>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {user.role === 'doctor' && (
              <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
                {(['morning', 'evening'] as ShiftType[]).map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setShift(s)}
                    className={`rounded-md px-3 py-1.5 text-xs font-medium capitalize ${
                      shift === s
                        ? 'bg-white text-slate-950 font-semibold shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {s} Shift
                  </button>
                ))}
              </div>
            )}

            <button
              type="button"
              onClick={() => void logout()}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
            >
              <LogOut className="h-3.5 w-3.5" />
              Sign Out
            </button>
          </div>
        </div>
      </section>

      {actionFeedback && (
        <div
          role="status"
          className={`rounded-xl border px-4 py-3 text-sm font-medium ${
            actionFeedback.isError
              ? 'border-red-200 bg-red-50 text-red-900'
              : 'border-emerald-200 bg-emerald-50 text-emerald-900'
          }`}
        >
          {actionFeedback.message}
        </div>
      )}

      {user.role === 'doctor' && board && (
        <>
          <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
            <div className="rounded-xl border border-slate-200 bg-white p-6 lg:col-span-2">
              <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-4">
                <div>
                  <h2 className="font-display text-lg font-bold text-slate-900">
                    Active Queue Control — {board.doctor.specialtyName}
                  </h2>
                  <p className="text-xs text-slate-600">
                    {board.doctor.clinicName} · {board.doctor.roomNumber} · EWMA:{' '}
                    <span className="font-mono font-semibold tabular-nums">
                      {board.ewmaMinutes.toFixed(1)} min
                    </span>
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <label htmlFor="console-status-select" className="text-xs font-medium text-slate-600">
                    Status:
                  </label>
                  <select
                    id="console-status-select"
                    value={board.doctorStatus}
                    onChange={(e) => {
                      const nextStatus = e.target.value as DoctorStatusType;
                      void runDoctorAction(
                        () =>
                          doctorSetStatus(
                            activeDoctorId,
                            shift,
                            nextStatus,
                            nextStatus === 'In Consultation'
                          ),
                        `Doctor status updated to ${nextStatus}.`
                      );
                    }}
                    className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-900 focus:border-teal-700 focus:outline-none"
                  >
                    <option value="In Consultation">In Consultation</option>
                    <option value="On Break">On Break</option>
                    <option value="Delayed">Delayed</option>
                  </select>
                </div>
              </div>

              <div className="mt-5 grid grid-cols-2 gap-4 rounded-xl bg-slate-50 p-4 sm:grid-cols-4">
                <div>
                  <div className="text-xs text-slate-500">Currently Serving</div>
                  <div className="mt-1 font-mono text-2xl font-bold tabular-nums text-teal-800">
                    {board.activeToken ? `#${board.activeToken.tokenNumber}` : 'None'}
                  </div>
                  <div className="mt-0.5 text-xs text-slate-600 truncate">
                    {board.activeToken?.patientName ?? 'Queue ready'}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Next Patient</div>
                  <div className="mt-1 font-mono text-2xl font-bold tabular-nums text-slate-900">
                    {board.nextToken ? `#${board.nextToken.tokenNumber}` : 'None'}
                  </div>
                  <div className="mt-0.5 text-xs text-slate-600 truncate">
                    {board.nextToken?.patientName ?? 'No waiting tokens'}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Waiting</div>
                  <div className="mt-1 font-mono text-2xl font-bold tabular-nums text-slate-900">
                    {board.waitingTokens.length}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Offset Delay</div>
                  <div className="mt-1 font-mono text-2xl font-bold tabular-nums text-amber-700">
                    +{board.offsetDelayMinutes}m
                  </div>
                </div>
              </div>

              <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2">
                <button
                  type="button"
                  disabled={actionBusy}
                  onClick={() =>
                    void runDoctorAction(
                      () => doctorCallNext(activeDoctorId, shift),
                      'Called next patient in queue and updated live patient wait times.'
                    )
                  }
                  className="inline-flex items-center justify-center gap-2 rounded-lg bg-teal-700 px-4 py-3 text-sm font-semibold text-white hover:bg-teal-800 disabled:opacity-60"
                >
                  <Play className="h-4 w-4" />
                  Next Patient
                </button>

                <button
                  type="button"
                  disabled={actionBusy}
                  onClick={() =>
                    void runDoctorAction(
                      () => doctorAddDelay(activeDoctorId, shift, 10),
                      'Added 10-minute delay and notified waiting patients.'
                    )
                  }
                  className="inline-flex items-center justify-center gap-2 rounded-lg border border-amber-300 bg-amber-50 px-4 py-3 text-sm font-semibold text-amber-950 hover:bg-amber-100 disabled:opacity-60"
                >
                  <Clock className="h-4 w-4" />
                  Delay 10 mins
                </button>

                <button
                  type="button"
                  disabled={actionBusy}
                  onClick={() =>
                    void runDoctorAction(
                      () => doctorSkipAbsent(activeDoctorId, shift),
                      'Moved absent patient to holding queue and advanced next token.'
                    )
                  }
                  className="inline-flex items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-3 text-sm font-semibold text-slate-800 hover:bg-slate-50 disabled:opacity-60"
                >
                  <UserX className="h-4 w-4 text-red-600" />
                  Patient Absent – Skip Token
                </button>

                <div className="flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 p-1.5">
                  <label htmlFor="completed-duration" className="sr-only">
                    Consultation duration in minutes
                  </label>
                  <input
                    id="completed-duration"
                    type="number"
                    min={5}
                    max={30}
                    value={completedDuration}
                    onChange={(e) => setCompletedDuration(Number(e.target.value))}
                    className="w-16 rounded-md border border-slate-300 bg-white px-2 py-1.5 text-center font-mono text-sm font-semibold tabular-nums text-slate-900"
                  />
                  <span className="text-xs text-slate-600">min</span>
                  <button
                    type="button"
                    disabled={actionBusy || !board.activeToken}
                    onClick={() =>
                      void runDoctorAction(
                        () =>
                          doctorMarkCompleted(
                            activeDoctorId,
                            shift,
                            completedDuration
                          ),
                        `Marked consultation completed (${completedDuration}m) and recalculated EWMA.`
                      )
                    }
                    className="ml-auto inline-flex items-center gap-1.5 rounded-md bg-slate-900 px-3 py-2 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-50 whitespace-nowrap"
                  >
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    Mark Completed
                  </button>
                </div>
              </div>

              <div className="mt-6 border-t border-slate-100 pt-5">
                <h3 className="text-sm font-semibold text-slate-900">
                  Waiting Queue ({board.waitingTokens.length})
                </h3>
                {board.waitingTokens.length === 0 ? (
                  <p className="mt-2 text-sm text-slate-500">No waiting patients.</p>
                ) : (
                  <ul className="mt-3 divide-y divide-slate-100">
                    {board.waitingTokens.map((token) => (
                      <li
                        key={token.id}
                        className="flex flex-wrap items-center justify-between gap-2 py-2.5 text-sm"
                      >
                        <div className="flex items-center gap-3">
                          <span className="font-mono font-bold tabular-nums text-slate-900">
                            #{token.tokenNumber}
                          </span>
                          <span className="font-medium text-slate-800">{token.patientName}</span>
                          {token.isEmergency && (
                            <span className="text-xs font-semibold text-red-700">
                              Emergency
                            </span>
                          )}
                          {token.checkedIn && (
                            <span className="text-xs font-medium text-emerald-700">
                              Checked In
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-3">
                          <span className="font-mono text-xs tabular-nums text-slate-500">
                            Est. {token.estimatedWaitMinutes}m
                          </span>
                          <button
                            type="button"
                            disabled={actionBusy}
                            onClick={() =>
                              void runDoctorAction(
                                () => doctorSkipAbsent(activeDoctorId, shift, token.id),
                                `Moved Token #${token.tokenNumber} to absent holding queue.`
                              )
                            }
                            className="rounded border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50"
                          >
                            Skip Absent
                          </button>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              {board.holdingTokens.length > 0 && (
                <div className="mt-6 border-t border-slate-100 pt-5">
                  <h3 className="text-sm font-semibold text-amber-900">
                    Absent Holding Queue ({board.holdingTokens.length})
                  </h3>
                  <ul className="mt-2 divide-y divide-slate-100">
                    {board.holdingTokens.map((token) => (
                      <li
                        key={token.id}
                        className="flex items-center justify-between py-2 text-sm"
                      >
                        <span>
                          <span className="font-mono font-semibold tabular-nums text-slate-900">
                            #{token.tokenNumber}
                          </span>{' '}
                          · {token.patientName}
                        </span>
                        <button
                          type="button"
                          disabled={actionBusy}
                          onClick={() =>
                            void runDoctorAction(
                              () => doctorRecallHolding(token.id),
                              `Recalled Token #${token.tokenNumber} back into waiting queue.`
                            )
                          }
                          className="inline-flex items-center gap-1 rounded border border-slate-200 px-2.5 py-1 text-xs font-medium text-teal-800 hover:bg-slate-50"
                        >
                          <RotateCcw className="h-3 w-3" />
                          Recall to Queue
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="space-y-6">
              <section className="rounded-xl border border-slate-200 bg-white p-6">
                <div className="flex items-center gap-2">
                  <FileUp className="h-4 w-4 text-teal-700" />
                  <h2 className="font-display text-base font-bold text-slate-900">
                    Digital Prescription Attachment
                  </h2>
                </div>
                <p className="mt-1 text-xs text-slate-600">
                  Attach summary PDF or consultation notes to a patient appointment record.
                </p>

                <form onSubmit={handlePrescriptionUpload} className="mt-4 space-y-3">
                  <div>
                    <label
                      htmlFor="rx-appointment"
                      className="block text-xs font-semibold text-slate-700"
                    >
                      Appointment Token
                    </label>
                    <select
                      id="rx-appointment"
                      value={rxAppointmentId}
                      onChange={(e) => setRxAppointmentId(Number(e.target.value))}
                      className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-900 focus:border-teal-700 focus:outline-none"
                    >
                      {doctorAppointments.map((a) => (
                        <option key={a.appointmentId} value={a.appointmentId}>
                          Token #{a.tokenNumber} — {a.patientName} ({a.status.replace('_', ' ')})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label htmlFor="rx-notes" className="block text-xs font-semibold text-slate-700">
                      Consultation Notes
                    </label>
                    <textarea
                      id="rx-notes"
                      rows={3}
                      value={rxNotes}
                      onChange={(e) => setRxNotes(e.target.value)}
                      placeholder="Rx / dosage instructions or clinical summary"
                      className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-900 focus:border-teal-700 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label htmlFor="rx-file" className="block text-xs font-semibold text-slate-700">
                      Summary PDF / Text File
                    </label>
                    <input
                      id="rx-file"
                      type="file"
                      accept=".pdf,.txt,application/pdf,text/plain"
                      onChange={(e) => setRxFile(e.target.files?.[0] ?? null)}
                      className="mt-1 block w-full text-xs text-slate-600 file:mr-3 file:rounded-md file:border file:border-slate-200 file:bg-slate-50 file:px-3 file:py-1.5 file:text-xs file:font-medium file:text-slate-700 hover:file:bg-slate-100"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={actionBusy}
                    className="w-full rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-60"
                  >
                    Attach Prescription to Record
                  </button>
                </form>
              </section>
            </div>
          </section>
        </>
      )}

      {user.role === 'triage_staff' && (
        <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div className="rounded-xl border border-slate-200 bg-white p-6">
            <div className="flex items-center gap-2.5">
              <AlertTriangle className="h-5 w-5 text-red-600" />
              <h2 className="font-display text-lg font-bold text-slate-900">
                Emergency Escalation Queue
              </h2>
            </div>
            <p className="mt-1 text-sm text-slate-600">
              Inject an urgent trauma or critical patient ahead of standard waiting tokens and
              recalculate clinic wait times.
            </p>

            <form onSubmit={handleTriageEmergency} className="mt-5 space-y-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="triage-clinic"
                    className="block text-xs font-semibold text-slate-700"
                  >
                    Clinic
                  </label>
                  <select
                    id="triage-clinic"
                    value={triageClinicId}
                    onChange={(e) => {
                      const nextCid = Number(e.target.value);
                      setTriageClinicId(nextCid);
                      const first = doctors.find((d) => d.clinicId === nextCid);
                      if (first) setTriageDoctorId(first.id);
                    }}
                    className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900"
                  >
                    {clinics.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="triage-doctor"
                    className="block text-xs font-semibold text-slate-700"
                  >
                    Specialist
                  </label>
                  <select
                    id="triage-doctor"
                    value={triageDoctorId}
                    onChange={(e) => setTriageDoctorId(Number(e.target.value))}
                    className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900"
                  >
                    {triageClinicDoctors.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.specialtyName})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <span className="block text-xs font-semibold text-slate-700">Shift</span>
                <div className="mt-1 grid grid-cols-2 gap-2">
                  {(['morning', 'evening'] as ShiftType[]).map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setTriageShift(s)}
                      className={`rounded-lg border px-3 py-2 text-xs font-medium capitalize ${
                        triageShift === s
                          ? 'border-teal-700 bg-teal-50 text-teal-900'
                          : 'border-slate-200 bg-white text-slate-700'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="triage-name"
                    className="block text-xs font-semibold text-slate-700"
                  >
                    Patient Name
                  </label>
                  <input
                    id="triage-name"
                    type="text"
                    required
                    value={triageName}
                    onChange={(e) => setTriageName(e.target.value)}
                    placeholder="Critical patient name"
                    className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
                <div>
                  <label
                    htmlFor="triage-phone"
                    className="block text-xs font-semibold text-slate-700"
                  >
                    Contact Phone
                  </label>
                  <input
                    id="triage-phone"
                    type="tel"
                    required
                    value={triagePhone}
                    onChange={(e) => setTriagePhone(e.target.value)}
                    placeholder="555-9110"
                    className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="triage-symptoms"
                  className="block text-xs font-semibold text-slate-700"
                >
                  Triage Assessment / Urgent Symptoms
                </label>
                <input
                  id="triage-symptoms"
                  type="text"
                  required
                  value={triageSymptoms}
                  onChange={(e) => setTriageSymptoms(e.target.value)}
                  placeholder="e.g. Acute chest tightness, triage level 1"
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>

              <button
                type="submit"
                disabled={actionBusy}
                className="w-full rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-red-700 disabled:opacity-60"
              >
                Escalate Emergency Priority Token
              </button>
            </form>
          </div>

          {board && (
            <div className="rounded-xl border border-slate-200 bg-white p-6">
              <h2 className="font-display text-lg font-bold text-slate-900">
                Target Queue Preview — {board.doctor.name}
              </h2>
              <p className="mt-1 text-xs text-slate-600">
                Now Serving:{' '}
                <span className="font-mono font-bold tabular-nums">
                  {board.activeToken ? `#${board.activeToken.tokenNumber}` : 'None'}
                </span>{' '}
                · Waiting: {board.waitingTokens.length}
              </p>
              <ul className="mt-4 divide-y divide-slate-100">
                {board.waitingTokens.map((t) => (
                  <li key={t.id} className="flex items-center justify-between py-2.5 text-sm">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold tabular-nums">#{t.tokenNumber}</span>
                      <span>{t.patientName}</span>
                      {t.isEmergency && (
                        <span className="text-xs font-semibold text-red-700">Emergency</span>
                      )}
                    </div>
                    <span className="font-mono text-xs tabular-nums text-slate-500">
                      Pos {t.queuePosition} · {t.estimatedWaitMinutes}m
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </section>
      )}

      <section className="rounded-xl border border-slate-200 bg-white p-6">
        <h2 className="font-display text-base font-bold text-slate-900">
          Structured Clinical Audit Trail
        </h2>
        <p className="mt-0.5 text-xs text-slate-600">
          Live Pino + SQLite audit log of queue transitions, escalations, and security events.
        </p>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[600px] border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="py-2 pr-4">Timestamp</th>
                <th className="py-2 pr-4">Event</th>
                <th className="py-2 pr-4">Actor</th>
                <th className="py-2 pr-4">Token</th>
                <th className="py-2">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {auditLogs.map((log) => (
                <tr key={log.id}>
                  <td className="py-2 pr-4 font-mono tabular-nums text-slate-500">
                    {new Date(log.createdAt).toLocaleTimeString()}
                  </td>
                  <td className="py-2 pr-4 font-mono font-semibold text-slate-900">
                    {log.event}
                  </td>
                  <td className="py-2 pr-4 text-slate-700">
                    {log.actorName} ({log.actorRole})
                  </td>
                  <td className="py-2 pr-4 font-mono tabular-nums text-slate-700">
                    {log.tokenNumber ? `#${log.tokenNumber}` : '—'}
                  </td>
                  <td className="py-2 font-mono text-slate-500 truncate max-w-xs">
                    {log.details}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
