import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Download, FileText, MapPin, Search } from 'lucide-react';
import type { PatientAppointmentDetail } from '../types/clinic.ts';
import {
  ApiError,
  checkInAppointmentGeo,
  fetchAppointments,
} from '../services/apiClient.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { useQueueSync } from '../hooks/useQueueSync.ts';
import { AnimatedTokenCounter } from '../components/AnimatedTokenCounter.tsx';
import { SmsAlertBanner } from '../components/SmsAlertBanner.tsx';

export function MyAppointmentsPage() {
  const { bookedIds } = useAuth();
  const [phoneQuery, setPhoneQuery] = useState('');
  const [appointments, setAppointments] = useState<PatientAppointmentDetail[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [geoStatus, setGeoStatus] = useState<
    Record<number, { loading: boolean; message: string | null; isError: boolean }>
  >({});
  const [countdownSeconds, setCountdownSeconds] = useState(0);

  const loadAppointments = useCallback(async () => {
    try {
      const trimmedPhone = phoneQuery.trim();
      const data = trimmedPhone
        ? await fetchAppointments({ phone: trimmedPhone })
        : bookedIds.length > 0
        ? await fetchAppointments({ ids: bookedIds })
        : await fetchAppointments();
      setAppointments(data);
      setError(null);
    } catch {
      setError('Unable to load appointment queue status.');
    } finally {
      setLoading(false);
    }
  }, [phoneQuery, bookedIds]);

  useEffect(() => {
    void loadAppointments();
  }, [loadAppointments]);

  useQueueSync(() => {
    void loadAppointments();
  }, 3000);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdownSeconds((s) => (s + 1) % 60);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleSearch = (e: FormEvent) => {
    e.preventDefault();
    void loadAppointments();
  };

  const submitGeolocation = async (
    appointmentId: number,
    latitude: number,
    longitude: number
  ) => {
    setGeoStatus((prev) => ({
      ...prev,
      [appointmentId]: { loading: true, message: null, isError: false },
    }));
    try {
      const res = await checkInAppointmentGeo(appointmentId, latitude, longitude);
      setGeoStatus((prev) => ({
        ...prev,
        [appointmentId]: {
          loading: false,
          message: `Checked in! Verified ${res.distanceMeters}m from clinic (within ${res.maxRadiusMeters}m radius).`,
          isError: false,
        },
      }));
      await loadAppointments();
    } catch (err) {
      const msg =
        err instanceof ApiError
          ? err.message
          : 'Unable to verify clinic proximity for check-in.';
      setGeoStatus((prev) => ({
        ...prev,
        [appointmentId]: { loading: false, message: msg, isError: true },
      }));
    }
  };

  const handleDeviceGeoCheckIn = (appt: PatientAppointmentDetail) => {
    if (!navigator.geolocation) {
      setGeoStatus((prev) => ({
        ...prev,
        [appt.appointmentId]: {
          loading: false,
          message: 'Device geolocation API is unavailable in this browser.',
          isError: true,
        },
      }));
      return;
    }

    setGeoStatus((prev) => ({
      ...prev,
      [appt.appointmentId]: {
        loading: true,
        message: 'Acquiring GPS coordinates...',
        isError: false,
      },
    }));

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        void submitGeolocation(
          appt.appointmentId,
          pos.coords.latitude,
          pos.coords.longitude
        );
      },
      (geoErr) => {
        setGeoStatus((prev) => ({
          ...prev,
          [appt.appointmentId]: {
            loading: false,
            message: `Geolocation access error: ${geoErr.message}.`,
            isError: true,
          },
        }));
      },
      { enableHighAccuracy: true, timeout: 6000 }
    );
  };

  return (
    <div className="space-y-6">
      <section className="rounded-xl border border-slate-200 bg-white p-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="font-display text-2xl font-bold text-slate-900">
              My Appointments
            </h1>
            <p className="mt-1 text-sm text-slate-600">
              Live token tracking, EWMA waiting-time countdown, geolocation check-in, and SMS alerts.
            </p>
          </div>

          <form onSubmit={handleSearch} className="flex flex-wrap items-center gap-2">
            <label htmlFor="appt-phone-search" className="sr-only">
              Lookup appointments by phone number
            </label>
            <div className="relative flex-1 sm:flex-initial">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                id="appt-phone-search"
                type="text"
                value={phoneQuery}
                onChange={(e) => setPhoneQuery(e.target.value)}
                placeholder="Phone (e.g. 555-9914)"
                className="w-full sm:w-64 rounded-lg border border-slate-300 bg-white py-2 pl-9 pr-3 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
              />
            </div>
            <button
              type="submit"
              className="rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm font-medium text-slate-800 hover:bg-slate-100"
            >
              Lookup
            </button>
            {phoneQuery.trim() && (
              <button
                type="button"
                onClick={() => setPhoneQuery('')}
                className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50"
              >
                Clear
              </button>
            )}
          </form>
        </div>
      </section>

      <SmsAlertBanner appointments={appointments} />

      {error && (
        <div role="alert" className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">
          {error}
        </div>
      )}

      {loading && appointments.length === 0 ? (
        <div className="h-48 animate-pulse rounded-xl border border-slate-200 bg-white p-6" />
      ) : appointments.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
          <h2 className="font-display text-lg font-semibold text-slate-900">
            No appointments found
          </h2>
          <p className="mt-1 text-sm text-slate-600">
            Book a consultation token from the Doctor Directory or clear the phone search filter.
          </p>
        </div>
      ) : (
        <div className="space-y-5">
          {appointments.map((appt) => {
            const gState = geoStatus[appt.appointmentId];
            const waitMins = appt.estimatedWaitMinutes;
            const liveMinutes =
              waitMins !== null && waitMins > 0
                ? Math.max(0, waitMins - (countdownSeconds > 0 ? 1 : 0))
                : waitMins;
            const liveSeconds =
              waitMins !== null && waitMins > 0 ? (60 - countdownSeconds) % 60 : 0;

            return (
              <article
                key={appt.appointmentId}
                data-testid={`appointment-card-${appt.tokenNumber}`}
                className="rounded-xl border border-slate-200 bg-white p-6"
              >
                <div className="flex flex-col gap-4 border-b border-slate-100 pb-4 sm:flex-row sm:items-start sm:justify-between">
                  <div>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                      <span className="font-semibold text-slate-900">{appt.patientName}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">{appt.patientPhone}</span>
                      <span aria-hidden="true">·</span>
                      <span className="capitalize">{appt.shift} shift</span>
                      {appt.isEmergency && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-semibold text-red-700">Emergency Priority</span>
                        </>
                      )}
                    </div>
                    <h2 className="mt-1 font-display text-xl font-bold text-slate-900">
                      {appt.doctor.name} — {appt.doctor.specialtyName}
                    </h2>
                    <p className="mt-0.5 text-sm text-slate-600">
                      {appt.clinic.name} ({appt.clinic.address}) · {appt.doctor.roomNumber}
                    </p>
                  </div>

                  <div className="text-left sm:text-right">
                    <div
                      className={`text-xs font-semibold capitalize ${
                        appt.status === 'in_consultation'
                          ? 'text-emerald-700'
                          : appt.status === 'holding'
                          ? 'text-amber-700'
                          : appt.status === 'waiting'
                          ? 'text-teal-700'
                          : 'text-slate-600'
                      }`}
                    >
                      Status: {appt.status.replace('_', ' ')}
                    </div>
                    <div className="mt-0.5 text-xs text-slate-500">
                      Doctor: {appt.doctor.status}
                      {appt.doctor.offsetDelayMinutes > 0
                        ? ` (+${appt.doctor.offsetDelayMinutes}m delay)`
                        : ''}
                    </div>
                  </div>
                </div>

                <div className="mt-5 grid grid-cols-2 gap-4 rounded-xl bg-slate-50 p-4 sm:grid-cols-4">
                  <div>
                    <div className="text-xs text-slate-500">Booked Token</div>
                    <div className="mt-1 text-2xl font-bold text-teal-800">
                      <AnimatedTokenCounter value={appt.tokenNumber} prefix="#" />
                    </div>
                  </div>

                  <div>
                    <div className="text-xs text-slate-500">Currently Serving</div>
                    <div className="mt-1 text-2xl font-bold text-slate-900">
                      {appt.currentlyServingTokenNumber !== null ? (
                        <AnimatedTokenCounter
                          value={appt.currentlyServingTokenNumber}
                          prefix="#"
                        />
                      ) : (
                        <span className="font-mono text-slate-400">—</span>
                      )}
                    </div>
                  </div>

                  <div>
                    <div className="text-xs text-slate-500">Patients Ahead</div>
                    <div className="mt-1 text-2xl font-bold text-slate-900">
                      {appt.patientsAhead !== null ? (
                        <AnimatedTokenCounter value={appt.patientsAhead} />
                      ) : (
                        <span className="font-mono text-slate-400">0</span>
                      )}
                    </div>
                  </div>

                  <div>
                    <div className="text-xs text-slate-500">Estimated Wait</div>
                    <div className="mt-1 text-2xl font-bold text-slate-900">
                      {waitMins !== null ? (
                        <AnimatedTokenCounter value={waitMins} suffix=" min" />
                      ) : (
                        <span className="font-mono text-slate-400">—</span>
                      )}
                    </div>
                    {waitMins !== null && waitMins > 0 && (
                      <div className="mt-0.5 font-mono text-xs tabular-nums text-slate-500">
                        Live countdown: {String(liveMinutes).padStart(2, '0')}:
                        {String(liveSeconds).padStart(2, '0')}
                      </div>
                    )}
                  </div>
                </div>

                <div className="mt-5 flex flex-col gap-3 border-t border-slate-100 pt-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex flex-wrap items-center gap-3">
                    {appt.checkedIn ? (
                      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700">
                        <MapPin className="h-4 w-4" />
                        Checked In at Clinic
                      </span>
                    ) : (
                      <>
                        <button
                          type="button"
                          disabled={gState?.loading || appt.status === 'completed'}
                          onClick={() => handleDeviceGeoCheckIn(appt)}
                          className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-800 hover:bg-slate-50 disabled:opacity-50"
                        >
                          <MapPin className="h-3.5 w-3.5 text-teal-700" />
                          {gState?.loading ? 'Locating...' : 'GPS Virtual Check-In (≤500m)'}
                        </button>
                        <button
                          type="button"
                          disabled={gState?.loading || appt.status === 'completed'}
                          onClick={() =>
                            void submitGeolocation(
                              appt.appointmentId,
                              appt.clinic.latitude + 0.0008,
                              appt.clinic.longitude
                            )
                          }
                          className="text-xs font-medium text-teal-700 underline-offset-2 hover:underline disabled:opacity-50"
                        >
                          Verify at Clinic Coordinates
                        </button>
                      </>
                    )}
                  </div>

                  {appt.prescription && (
                    <div className="flex items-center gap-3 rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2">
                      <FileText className="h-4 w-4 text-teal-700 shrink-0" />
                      <div className="text-xs">
                        <div className="font-semibold text-slate-900">
                          {appt.prescription.fileName}
                        </div>
                        {appt.prescription.notes && (
                          <div className="text-slate-600">{appt.prescription.notes}</div>
                        )}
                      </div>
                      <a
                        href={`/api/appointments/${appt.appointmentId}/prescription/download`}
                        className="inline-flex items-center gap-1 rounded-md bg-white px-2.5 py-1 text-xs font-medium text-teal-800 border border-slate-200 hover:bg-slate-100"
                      >
                        <Download className="h-3.5 w-3.5" />
                        Download
                      </a>
                    </div>
                  )}
                </div>

                {gState?.message && (
                  <p
                    role="status"
                    className={`mt-2 text-xs font-medium ${
                      gState.isError ? 'text-red-700' : 'text-emerald-700'
                    }`}
                  >
                    {gState.message}
                  </p>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
