import type {
  AuditLogEntry,
  AuthUser,
  Clinic,
  Doctor,
  DoctorQueueBoard,
  DoctorStatusType,
  HeatmapCell,
  PaginatedTokenHistory,
  PatientAppointmentDetail,
  PrescriptionAttachment,
  ShiftType,
  Specialty,
} from '../types/clinic.ts';

let cachedCsrfToken: string | null = null;

export class ApiError extends Error {
  status: number;
  code: string;

  constructor(status: number, code: string, message: string) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
  }
}

export async function ensureCsrfToken(): Promise<string> {
  if (cachedCsrfToken) {
    return cachedCsrfToken;
  }
  const res = await fetch('/api/auth/csrf', { credentials: 'include' });
  const data = (await res.json()) as { csrfToken?: string };
  if (data.csrfToken) {
    cachedCsrfToken = data.csrfToken;
    return data.csrfToken;
  }
  throw new ApiError(500, 'CSRF_INIT_FAILED', 'Unable to initialize security token');
}

async function apiFetch<T>(url: string, options: RequestInit = {}): Promise<T> {
  const method = (options.method ?? 'GET').toUpperCase();
  const headers = new Headers(options.headers);

  if (method !== 'GET' && method !== 'HEAD' && url !== '/api/auth/login' && url !== '/api/auth/logout') {
    const token = await ensureCsrfToken();
    headers.set('X-CSRF-Token', token);
  }

  if (options.body && !(options.body instanceof FormData) && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  const res = await fetch(url, {
    ...options,
    headers,
    credentials: 'include',
  });

  const contentType = res.headers.get('content-type') ?? '';
  const payload = contentType.includes('application/json') ? await res.json() : null;

  if (!res.ok) {
    // If CSRF cookie expired or reset, refresh once and retry
    if (res.status === 403 && payload?.error?.message?.includes('CSRF')) {
      cachedCsrfToken = null;
      const freshToken = await ensureCsrfToken();
      headers.set('X-CSRF-Token', freshToken);
      const retryRes = await fetch(url, { ...options, headers, credentials: 'include' });
      const retryPayload = await retryRes.json();
      if (retryRes.ok) {
        return retryPayload as T;
      }
      throw new ApiError(
        retryRes.status,
        retryPayload?.error?.code ?? 'REQUEST_FAILED',
        retryPayload?.error?.message ?? 'Request failed'
      );
    }

    throw new ApiError(
      res.status,
      payload?.error?.code ?? 'REQUEST_FAILED',
      payload?.error?.message ?? `Request failed with status ${res.status}`
    );
  }

  return payload as T;
}

export async function fetchCurrentUser(): Promise<AuthUser | null> {
  const data = await apiFetch<{ user: AuthUser | null }>('/api/auth/me');
  return data.user;
}

export async function loginAccount(email: string, password: string): Promise<AuthUser> {
  const data = await apiFetch<{ user: AuthUser; csrfToken: string }>('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });
  cachedCsrfToken = data.csrfToken;
  return data.user;
}

export async function logoutAccount(): Promise<void> {
  await apiFetch('/api/auth/logout', { method: 'POST' });
}

export async function fetchClinics(): Promise<Clinic[]> {
  const data = await apiFetch<{ clinics: Clinic[] }>('/api/clinics');
  return data.clinics;
}

export async function fetchSpecialties(): Promise<Specialty[]> {
  const data = await apiFetch<{ specialties: Specialty[] }>('/api/specialties');
  return data.specialties;
}

export async function fetchDoctors(filters?: {
  clinicId?: number;
  specialty?: string;
}): Promise<Doctor[]> {
  const params = new URLSearchParams();
  if (filters?.clinicId) params.set('clinicId', String(filters.clinicId));
  if (filters?.specialty && filters.specialty !== 'All') {
    params.set('specialty', filters.specialty);
  }
  const query = params.toString();
  const data = await apiFetch<{ doctors: Doctor[] }>(`/api/doctors${query ? `?${query}` : ''}`);
  return data.doctors;
}

export async function fetchQueueBoards(filters?: {
  clinicId?: number;
  doctorId?: number;
  specialty?: string;
  shift?: ShiftType;
}): Promise<DoctorQueueBoard[]> {
  const params = new URLSearchParams();
  if (filters?.clinicId) params.set('clinicId', String(filters.clinicId));
  if (filters?.doctorId) params.set('doctorId', String(filters.doctorId));
  if (filters?.specialty && filters.specialty !== 'All') {
    params.set('specialty', filters.specialty);
  }
  if (filters?.shift) params.set('shift', filters.shift);
  const query = params.toString();
  const data = await apiFetch<{ boards: DoctorQueueBoard[] }>(
    `/api/queue/board${query ? `?${query}` : ''}`
  );
  return data.boards;
}

export async function bookAppointment(payload: {
  clinicId: number;
  doctorId: number;
  shift: ShiftType;
  patientName: string;
  patientPhone: string;
  symptoms?: string;
}): Promise<PatientAppointmentDetail> {
  const data = await apiFetch<{ appointment: PatientAppointmentDetail }>('/api/appointments', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
  return data.appointment;
}

export async function fetchAppointments(filters?: {
  phone?: string;
  ids?: number[];
}): Promise<PatientAppointmentDetail[]> {
  const params = new URLSearchParams();
  if (filters?.phone) params.set('phone', filters.phone);
  if (filters?.ids && filters.ids.length > 0) params.set('ids', filters.ids.join(','));
  const query = params.toString();
  const data = await apiFetch<{ appointments: PatientAppointmentDetail[] }>(
    `/api/appointments${query ? `?${query}` : ''}`
  );
  return data.appointments;
}

export async function checkInAppointmentGeo(
  appointmentId: number,
  latitude: number,
  longitude: number
): Promise<{
  checkedIn: boolean;
  distanceMeters: number;
  maxRadiusMeters: number;
  appointment: PatientAppointmentDetail;
}> {
  return apiFetch(`/api/appointments/${appointmentId}/checkin`, {
    method: 'POST',
    body: JSON.stringify({ latitude, longitude }),
  });
}

export async function doctorCallNext(
  doctorId: number,
  shift: ShiftType
): Promise<DoctorQueueBoard> {
  const data = await apiFetch<{ board: DoctorQueueBoard }>('/api/console/call-next', {
    method: 'POST',
    body: JSON.stringify({ doctorId, shift }),
  });
  return data.board;
}

export async function doctorMarkCompleted(
  doctorId: number,
  shift: ShiftType,
  durationMinutes: number
): Promise<DoctorQueueBoard> {
  const data = await apiFetch<{ board: DoctorQueueBoard }>('/api/console/complete', {
    method: 'POST',
    body: JSON.stringify({ doctorId, shift, durationMinutes }),
  });
  return data.board;
}

export async function doctorAddDelay(
  doctorId: number,
  shift: ShiftType,
  delayMinutes = 10
): Promise<DoctorQueueBoard> {
  const data = await apiFetch<{ board: DoctorQueueBoard }>('/api/console/delay', {
    method: 'POST',
    body: JSON.stringify({ doctorId, shift, delayMinutes }),
  });
  return data.board;
}

export async function doctorSetStatus(
  doctorId: number,
  shift: ShiftType,
  status: DoctorStatusType,
  resetDelay = false
): Promise<DoctorQueueBoard> {
  const data = await apiFetch<{ board: DoctorQueueBoard }>('/api/console/status', {
    method: 'POST',
    body: JSON.stringify({ doctorId, shift, status, resetDelay }),
  });
  return data.board;
}

export async function doctorSkipAbsent(
  doctorId: number,
  shift: ShiftType,
  targetTokenId?: number
): Promise<DoctorQueueBoard> {
  const data = await apiFetch<{ board: DoctorQueueBoard }>('/api/console/skip-absent', {
    method: 'POST',
    body: JSON.stringify({ doctorId, shift, targetTokenId }),
  });
  return data.board;
}

export async function doctorRecallHolding(tokenId: number): Promise<DoctorQueueBoard> {
  const data = await apiFetch<{ board: DoctorQueueBoard }>('/api/console/recall-holding', {
    method: 'POST',
    body: JSON.stringify({ tokenId }),
  });
  return data.board;
}

export async function uploadPrescriptionAttachment(
  appointmentId: number,
  notes: string,
  file: File | null
): Promise<PrescriptionAttachment> {
  const formData = new FormData();
  formData.append('notes', notes);
  if (file) {
    formData.append('file', file);
  }
  const data = await apiFetch<{ prescription: PrescriptionAttachment }>(
    `/api/console/appointments/${appointmentId}/prescription`,
    {
      method: 'POST',
      body: formData,
    }
  );
  return data.prescription;
}

export async function triageEscalateEmergency(payload: {
  clinicId: number;
  doctorId: number;
  shift: ShiftType;
  patientName: string;
  patientPhone: string;
  symptoms: string;
}): Promise<{ appointment: PatientAppointmentDetail; board: DoctorQueueBoard }> {
  return apiFetch('/api/triage/emergency', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export async function fetchHeatmap(clinicId?: number): Promise<HeatmapCell[]> {
  const query = clinicId ? `?clinicId=${clinicId}` : '';
  const data = await apiFetch<{ heatmap: HeatmapCell[] }>(`/api/analytics/heatmap${query}`);
  return data.heatmap;
}

export async function fetchTokenHistory(params: {
  page: number;
  limit: number;
  clinicId?: number;
  doctorId?: number;
  status?: string;
}): Promise<PaginatedTokenHistory> {
  const qs = new URLSearchParams({
    page: String(params.page),
    limit: String(params.limit),
  });
  if (params.clinicId) qs.set('clinicId', String(params.clinicId));
  if (params.doctorId) qs.set('doctorId', String(params.doctorId));
  if (params.status && params.status !== 'all') qs.set('status', params.status);
  const data = await apiFetch<{ history: PaginatedTokenHistory }>(
    `/api/queue/history?${qs.toString()}`
  );
  return data.history;
}

export async function fetchAuditLogs(limit = 40): Promise<AuditLogEntry[]> {
  const data = await apiFetch<{ logs: AuditLogEntry[] }>(`/api/queue/audit?limit=${limit}`);
  return data.logs;
}
